<template>食物列表</template>

<script>
export default {};
</script>

<style>
</style>