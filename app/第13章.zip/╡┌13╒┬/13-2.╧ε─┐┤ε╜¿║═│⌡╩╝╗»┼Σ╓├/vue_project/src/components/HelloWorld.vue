<template>
  <div class="hello">
    <div>vue3仿美团项目</div>
    <van-button type="primary">主要按钮</van-button>
    <svg class="icon" aria-hidden="true">
      <use xlink:href="#icon-iconfonttubiaozhizuo-2"></use>
    </svg>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
};
</script>

<style  lang='less' scoped>
.hello {
  font-size: 20px;
  div {
    color: red;
  }
}
</style>
