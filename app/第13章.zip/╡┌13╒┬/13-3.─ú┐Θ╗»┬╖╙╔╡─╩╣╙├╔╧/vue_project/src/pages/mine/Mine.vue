<template>
  <div class="mine">
    <div class="content">我的</div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>