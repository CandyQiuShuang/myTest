<template>
  <div class="cart">
    <div class="content">购物车</div>
    <Footer />
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>