<template>
  <div class="order">
    <div class="content">订单</div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>