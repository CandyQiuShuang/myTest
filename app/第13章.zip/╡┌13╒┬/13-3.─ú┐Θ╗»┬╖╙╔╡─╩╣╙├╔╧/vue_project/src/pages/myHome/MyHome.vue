<template>
  <div class="home">
    <div class="content"></div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>