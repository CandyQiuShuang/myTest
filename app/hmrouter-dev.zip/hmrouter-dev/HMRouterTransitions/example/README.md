# 卡片一镜到底示例

[示例1](https://gitee.com/hadss/hmrouter/tree/dev/HMRouterExamples/features/custom_template_cases/src/main/ets/ezLongTake)