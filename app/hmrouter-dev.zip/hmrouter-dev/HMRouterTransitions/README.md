# HMRouterTransitions高阶转场动画库
HMRouterTransitions基于HMRouter封装了高阶转场动效，以及一系列HMRouter自定义模板

当前提供卡片一镜到底转场动画，后续会陆续补充更多动画效果

# 依赖系统版本

HarmonyOS NEXT Developer Beta5及以上

> 手机版本：NEXT.0.0.60及以上

# 下载安装
使用ohpm安装依赖

```shell
ohpm install @hadss/hmrouter
ohpm install @hadss/hmrouter-transitions
```

## 快速开始

### 在UIAbility初始化

```extendtypescript
export default class PhoneAbility extends UIAbility {
  
  onWindowStageCreate(windowStage: window.WindowStage): void {
    HMRouterTransitions.init(windowStage);
  }
};
```

### 配置页面模板

通过[HMRouter自定义模板](https://gitee.com/hadss/hmrouter/blob/dev/docs/CustomTemplate.md)能力配置一镜到底页面模板
```json5
{
  "customPageTemplate": [
    {
      "srcPath": [
        "**/CardLongTakePageTwo.ets" // 一镜到底目标页面
      ],
      "templatePath": "./oh_modules/@hadss/hmrouter-transitions/ets/template/CardLongTakeTemplate.ejs" // HMRouterTransitions提供的模板文件地址
    }
  ]
}
```

### 一镜到底转场动画的实现

使用一镜到底页面模版：`./oh_modules/@hadss/hmrouter-transitions/ets/template/CardLongTakeTemplate.ejs`

源页面指的是卡片承载页面，需要通过`HMRouterTransitions.cardLongTake`获取转场动画，然后通过`HMRouterMgr.push`传入一次性动画跳转目标页面

`HMRouterTransitions.cardLongTake(clickedComponentId: string,
targetComponentId: string, options?: LongTakeTransitionOptions)`接口用于生成一镜到底动画

- clickedComponentId: string，标识源页面点击卡片对应的id;
- targetComponentId: string，目标页面承载卡片内容对应的组件id;
- options?: LongTakeTransitionOptions, 可选参数，定义一镜到底动画开始的回调，以及从目标页面返回到源页面时的结束回调，可以用来控制卡片的显隐状态

**页面实现以及跳转方式**

起始页面
```extendtypescript
@HMRouter({ pageUrl: 'CardLongTakePageOne' })
@Component
export struct CardLongTakePageOne {
  @State dataSource: WaterFlowDataSource = new WaterFlowDataSource();
  
  build() {
    Stack() {
      WaterFlow() {
        LazyForEach(this.dataSource, (item: CardAttr, index: number) => {
          FlowItem() {
            CardComponent();
          }
          .id(Constants.getFlowItemIdByIndex(index.toString())) // 对应clickedComponentId
        }, (item: string) => item);
      }
      .cachedCount(4)
      .columnsTemplate(this.columnType)
      .columnsGap(5)
      .rowsGap(5)
      .width('100%')
      .height('100%');
    }
    .size({ width: '100%', height: '100%' })
    .padding({ left: 10, right: 10 });
  }
}
```

目标页面
```extendtypescript
@HMRouter({ pageUrl: 'CardLongTakePageTwo' })
@Component
export struct DetailPageContent {
  @Prop indexValue: number;

  build() {
    Column() {
      this.MyTitleBuilder()
      Image($r(`app.media.img_${this.indexValue % 6}`))
        .size({ width: '100%' })
        .objectFit(ImageFit.Auto)
        .id('targetId') // 对应targetComponentId参数
  
      Text($r('app.string.DetailPage_text'))
        .width(px2vp(WindowUtils.windowWidth_px))
        .margin({ top: 20 }).padding(10)
    }.backgroundColor(Color.White)
    .expandSafeArea([SafeAreaType.SYSTEM])
    .backgroundColor(Color.White)
  }
}
```

路由跳转使用方法

```extendtypescript
const animator = HMRouterTransitions.cardLongTake(Constants.getFlowItemIdByIndex(index.toString()), 'targetId', {
    onTransitionStart: () => {
      Logger.info('onTransitionStart');
    },
    onTransitionEnd: () => {
      Logger.info('onTransitionEnd');
    }
  });
HMRouterMgr.push({ pageUrl: 'CardLongTakePageTwo', param: index, animator: animator });
```

# 示例代码
[查看详情](https://gitee.com/hadss/hmrouter/blob/dev/HMRouterExamples/features/custom_template_cases/src/main/ets/ezLongTake/CardLongTakePageOne.ets)

# 接口和属性列表
[查看详情](https://gitee.com/hadss/hmrouter/blob/dev/docs/HMRouterTransitionsReference.md)

# FAQ
[查看详情](https://gitee.com/hadss/hmrouter/blob/dev/docs/HMRouterTransitionsFAQ.md)
