# 原生到原生页面跳转场景解决方案

工程中提供HMRouter使用子场景示例，可以通过查看HMRouterExamples模块下的代码查看，工程示例运行通过选择phone模块，点击启动运行即可  
<img src="./assets/image-20241029102631.png" alt="Image 1" height="400px" style="display: inline; height: 400px; margin-right: 10px;">
<img src="./assets/image-20241029103833688.jpeg" alt="Image 1" height="400px" style="display: inline; height: 400px; vertical-align: top;">

> **说明:**  
> 由于示例工程中有在线的H5跳转场景，建议设备联网之后查看完整运行效果

## 路由跳转场景
### 跳转其他har/hsp模块页面
当按路由页面分模块存放时，集成har/hsp模块并做路由跳转，需要在har/hsp模块下的hvigorfile.ts文件中添加插件  
har模块的hvigorfile.ts配置harPlugin插件
```extendtypescript
import { harTasks } from '@ohos/hvigor-ohos-plugin';
import { harPlugin } from '@hadss/hmrouter-plugin';

export default {
  system: harTasks,
  plugins:[harPlugin()]
}
```
hsp模块的hvigorfile.ts配置hspPlugin插件
```extendtypescript
import { hspTasks } from '@ohos/hvigor-ohos-plugin';
import { hspPlugin } from '@hadss/hmrouter-plugin';

export default {
  system: hspTasks,
  plugins: [hspPlugin()]
};
```
然后在需要集成相应的har/hsp模块的hap下的oh-package.json5文件添加相应模块依赖，配置完上述内容之后，即可使用HMRouterMgr提供的路由方法做路由跳转  
例如har模块定义路由页面：
```extendtypescript
@HMRouter({ pageUrl: 'JumpHarPageCase'})
@Component
export struct JumpHarPageCase {

  build() {
    Flex() {
    }
  }
}
```
然后在hap或者其他模块跳转到定义的har模块页面，使用`HMRouterMgr.push({ pageUrl: 'JumpHarPageCase' })`即可跳转

### 跳转pageUrl常量定义页面
@HMRouter定义的pageUrl支持在本模块的常量定义，通过import导入常量定义，然后在@HMRouter定义时使用
```extendtypescript
import { PageConstants } from '../../constants/PageConstants';

@HMRouter({ pageUrl: PageConstants.JUMP_CONSTANT_PAGE_CASE })
@Component
export struct JumpConstantPageCase {
  build() {
    //...
  }
}
```

### 跳转pageUrl正则定义页面
@HMRouter配置的pageUrl支持正则格式，通过isRegex标识配置的pageUrl是正则格式，regexPriority配置匹配的优先级，数字越大优先级越高

例如页面定义路径如下：
```extendtypescript
@HMRouter({ pageUrl: 'JumpRegexPageCase\/.*', isRegex: true, regexPriority: 10 })
@Component
export struct JumpRegexPageCase {

  build() {
    //...
  }
}
```
路由跳转时使用`HMRouterMgr.push({ pageUrl: 'JumpRegexPageCase/12345' })`，可以正确匹配到上述定义页面


### 带参的路由跳转\返回

带参的路由跳转\返回是路由中最常见的业务场景，例如从pageA带参数跳转到pageB，在pageB获取到pageA的参数，当pageB返回pageA时，将返回值传递给pageA。

HMRouter实现方案：
#### 1.使用param方式传参
a.起始页面，通过`HMRouterMgr.push`方法指定跳转路由JumpWithParamPage和需要传递的参数对象this.param，同时配置HMRouterPathCallback的onResult方法，接收返回的页面参数。

```extendtypescript
Button('param方式传参数').onClick(() => {
  HMRouterMgr.push({ pageUrl: 'JumpWithParamPage', param: 12345 }, {
    onArrival: () => {
      this.logString = '';
    },
    onResult: (popInfo) => {
      if (popInfo.result) {
        this.logString = popInfo.result.toString();
      }
    }
  });
});
```

b.目标页面，通过`HMRouterMgr.getCurrentParam()`或者通过方法`HMRouterMgr.getCurrentParam(HMParamType.routeParam)`获取传入参数，当页面需要返回时，调用`HMRouterMgr.pop(info: HMRouterPathInfo)`方法返回，需要返回的参数对象this.backParam，返回后发起页面的onResult方法会被触发，业务可在此处进行返回值处理。

```extendtypescript
@HMRouter({ pageUrl: 'JumpWithParamPage' })
@Component
export struct JumpWithParamPage {
  @State logString: string = '';
  
  aboutToAppear(): void {
    const params = HMRouterMgr.getCurrentParam(HMParamType.routeParam);
    this.logString = `页面参数：${JSON.stringify(params)}`
  }
  
  build() {
    Flex() {
      Button('返回上一页').onClick(() => {
        HMRouterMgr.pop({ param: 'this is paramPage param' });
      });
    }.attributeModifier(this.baseContentStyles);
  }
}
```
#### 2.使用url方式传参
a.起始页面，通过`HMRouterMgr.push`方法指定跳转路由，参数可以通过url的query方式传递，同时配置HMRouterPathCallback的onResult方法，接收返回的页面参数。
```extendtypescript
Button('url方式传参数').onClick(() => {
  HMRouterMgr.push({ pageUrl: 'JumpWithQueryParamPage?abc=zhang&abc=123&b=true' }, {
    onArrival: () => {
      this.logString = '';
    },
    onResult: (popInfo) => {
      if (popInfo.result) {
        this.logString = popInfo.result.toString();
      }
    }
  });
});
```
b.目标页面，通过`HMRouterMgr.getCurrentParam(HMParamType.urlParam)`获取传入参数，当页面需要返回时，调用`HMRouterMgr.pop(info: HMRouterPathInfo)`方法返回，需要返回的参数对象this.backParam，返回后发起页面的onResult方法会被触发，业务可在此处进行返回值处理。
```extendtypescript
@HMRouter({ pageUrl: 'JumpWithQueryParamPage' })
@Component
export struct JumpWithQueryParamPage {
  @State logString: string = '';
  
  aboutToAppear(): void {
    const params = HMRouterMgr.getCurrentParam(HMParamType.urlParam) as Map<string, Object>;
    this.logString = '页面参数：\n';
    for (let key of params) {
      this.logString += `${key[0]}=${key[1]}\n`
    }
  }

  build() {
    Flex() {
      Button('返回上一页').onClick(() => {
        HMRouterMgr.pop({ param: 'this is queryPage param' });
      });
    }.attributeModifier(this.baseContentStyles);
  }
}
```


### 多级路由跳转，指定页面返回，并携带参数

多级路由返回可以通过调用`HMRouterMgr.pop`方法时，指定栈内的pageUrl，或者通过skipedLayerNumber参数指定需要返回的层级数量。

```extendtypescript
@HMRouter({ pageUrl: PageConstants.MULTI_JUMP_WITH_PARAM_CASE })
@Component
export struct MultiJumpWithParamCase {
  build() {
    Flex() {
      Button('跳转页面B').onClick(() => {
        HMRouterMgr.push({ pageUrl: 'MultiJumpWithParamPageB' }, {
          onResult: (popInfo) => {
            if (popInfo.result) {
              this.logString = popInfo.result.toString();
            }
          }
        });
      });
    }
  }
}

@HMRouter({ pageUrl: 'MultiJumpWithParamPageB' })
@Component
export struct MultiJumpWithParamPageB {
  build() {
    Flex() {
      Button('返回多级路由案例首页').onClick(() => {
        HMRouterMgr.pop({ pageUrl: PageConstants.MULTI_JUMP_WITH_PARAM_CASE, param: 'this is PageB param' });
      });
    }
  }
}
```

### 在弹窗页面跳转新页面，新页面返回后弹窗不关闭

弹窗隐私协议场景：隐私协议通过弹窗实现，点击具体隐私协议弹窗中的具体协议时，会跳转至协议页面，协议页面返回后隐私协议弹窗仍然存在。
为了实现弹窗不消失的业务场景，我们需要构建一个DIALOG类型的路由页面，通过将HMRouter标签的dialog字段配置成true，即可实现一个DIALOG类型的路由。

> 此类路由特点与DIALOG类型的NavDestinaion保持一致：默认透明，不影响其他NavDestination的生命周期。

```extendtypescript
@HMRouter({ pageUrl: 'PrivacyDialogPage', dialog: true })
@Component
export struct PrivacyDialogPage {
  
  build() {
    Column() {
      Button()
        .onClick(() => {
          HMRouterMgr.push({ pageUrl: 'https://privacy.consumer.huawei.com/legal/id/authentication-terms.htm?code=CN&language=zh-CN' });
        })
    }
  }
}
```
### 单例页面跳转

如视频播放场景中，常常会将视频播放页面配置为单例页面，这样就可以避免多个页面配置多个播放器。
对于单例页面，只需要配置HMRouter标签时，将singleton字段配置为true即可，
单例页面跳转会触发页面定义的onPrepare生命周期，可以在该方法中接收单例页面参数。

```extendtypescript
@HMLifecycle({ lifecycleName: 'SinglePageCaseLifecycle' })
export class SinglePageCaseLifecycle implements IHMLifecycle {
  pageParam: number = 0;
  
  onPrepare(ctx: HMLifecycleContext): void {
    const param = HMRouterMgr.getCurrentParam();
    if (typeof param === 'number') {
      this.pageParam = param
    } else {
      this.pageParam = 0;
    }
  }
}

@HMRouter({ pageUrl: PageConstants.SINGLE_PAGE_CASE, singleton: true, lifecycle: 'SinglePageCaseLifecycle' })
@Component
export struct SinglePageCase {
  build() {
    Flex() {
      Button('push to 单例页面').onClick(() => {
        HMRouterMgr.push({ pageUrl: PageConstants.SINGLE_PAGE_CASE, param: this.lifecycle.pageParam + 1 });
      });
    }
  }
}
```

### 嵌套路由

当存在路由嵌套的场景，HMNavigation嵌套HMNavigation的时候就会产生嵌套路由，当被嵌套的页面需要驱动主路由跳转时，需要在`HMRouterMgr.push({navigationId : 'mainNav', pageUrl : 'HomeContent'})`中指定navigationId进行跳转。
navigationId在声明HMNavigation时指定。

```extendtypescript
@Entry
@Component
struct Index {
  build() {
    Column() {
      HMNavigation({
        navigationId: 'mainNav', homePageUrl: PageConstants.NEST_NAVIGATION_CASE
      })
    }
    .height('100%')
    .width('100%')
  }
}

@HMRouter({ pageUrl: PageConstants.NEST_NAVIGATION_CASE })
@Component
export struct NestNavigationCase {
  build() {
    Flex() {
      HMNavigation({
        navigationId: 'childNavigation',
        homePageUrl: 'ChildRouterPage'
      })
    }
  }
}
```
## 拦截跳转场景

### 跳转H5页面，拦截器重定向
全局拦截器定义通过@HMInterceptor定义时的global参数标识，当为true时，则为全局拦截器不需要和页面之间建立绑定关系；
下述示例通过判断跳转链接是否是在线链接地址，如果是则跳转到ArkWeb所在组件页面打开链接，当发生路由跳转`HMRouterMgr.push({ pageUrl: 'http://xxxx' })`
时，将通过全局拦截器，重定向到H5Page页面
```extendtypescript
@HMInterceptor({ interceptorName: 'H5GlobalInterceptor', global: true, priority: 100 })
export class GlobalInterceptor implements IHMInterceptor {
  handle(info: HMInterceptorInfo): HMInterceptorAction {
    let uriObj: uri.URI | null = null;
    if (info.routerPathInfo.pageUrl) {
      try {
        uriObj = new uri.URI(info.routerPathInfo.pageUrl!);
      } catch (e) {
        Logger.info(e.message);
      }
    }
    if (uriObj?.scheme === 'http' || uriObj?.scheme === 'https') {
      HMRouterMgr.push({
        pageUrl: 'H5Page',
        param: info.routerPathInfo.pageUrl
      });
      return HMInterceptorAction.DO_REJECT;
    } else {
      return HMInterceptorAction.DO_NEXT;
    }
  }
}

@HMRouter({ pageUrl: 'H5Page' })
@Component
export struct H5Page {
  private h5Path: string = HMRouterMgr.getCurrentParam() as string;
  private controller: webview.WebviewController = new webview.WebviewController();

  build() {
    Column() {
      Web({ src: this.h5Path, controller: this.controller })
        .expandSafeArea([SafeAreaType.SYSTEM], [SafeAreaEdge.BOTTOM])
    }.justifyContent(FlexAlign.Center).width('100%').height('100%')
  }
}
```

### 页面返回确认弹窗
当某些页面在做退出操作时，需要二次确认是否退出页面，由于生命周期提供的onBackPress只能拦截手势操作，点击页面关闭按钮时onBackPress无法拦截，这种场景下
页面返回弹窗需要使用到拦截器，即从支付页面返回时，通过拦截器将路由跳转拦截，从而实现弹窗提示。

当拦截中需要进行拦截处理时，需要返回HMInterceptorAction.DO_REJECT，将当前此次跳转的拦截和路由动作停止。

1.申明返回拦截器

由于需要弹窗并额外处理路由，因此此处需要返回HMInterceptorAction.DO_REJECT，终止当前路由动作。

```extendtypescript
@HMInterceptor({ interceptorName: 'PopConfirmInterceptor' })
export class PopConfirmInterceptor implements IHMInterceptor {
  handle(info: HMInterceptorInfo): HMInterceptorAction {
    if (info.isSrc === true && info.routerPathInfo.param !== true) {
      info.context.getPromptAction().showDialog({
        title: '提示',
        message: '是否退出当前页面？',
        buttons: [
          {
            text: '取消',
            color: $r('app.color.text_blue')
          },
          {
            text: '确定',
            color: $r('app.color.text_red')
          }
        ]
      }).then((value) => {
        if (value.index === 1) {
          HMRouterMgr.pop({ param: true });
        }
      });
      return HMInterceptorAction.DO_REJECT;
    } else {
      return HMInterceptorAction.DO_NEXT;
    }
  }
}
```
2.声明`onBackPress`生命周期，拦截页面手势返回
```extendtypescript
@HMLifecycle({ lifecycleName: 'popConfirmLifecycle' })
@Observed
export class PopConfirmLifecycle implements IHMLifecycle {
  onBackPressed(ctx: HMLifecycleContext): boolean {
    ctx.uiContext.getPromptAction().showDialog({
      title: '提示',
      message: '是否退出当前页面？',
      buttons: [
        {
          text: '取消',
          color: $r('app.color.text_blue')
        },
        {
          text: '确定',
          color: $r('app.color.text_red')
        }
      ]
    }).then((value) => {
      if (value.index === 1) {
        HMRouterMgr.pop({ param: true });
      }
    });
    return true
  }
}
```

3.将拦截器和声明周期作用在页面上

```extendtypescript
@HMRouter({ pageUrl: 'HMInterceptor://popConfirm', interceptors: ['PopConfirmInterceptor'], lifecycle: 'popConfirmLifecycle' })
@Component
export struct PopConfirm {
  build() {
    Flex() {
      Button('返回').onClick(() => {
        HMRouterMgr.pop();
      })
    }
  }
}
```

### 登录拦截，重定向到登录页面

登录校验场景，如从首页点击查看某个需要登录才能查看的信息页面。
此场景也可以通过拦截器实现，需要在拦截器中判断登录状态是否已登录，未登录情况下拦截登录跳转，打开登录页面，实现登录之后`HMRouter.pop`关闭弹窗之后，
触发拦截器内跳转时传入的`onResult`回调，在回调内打开信息页面。

> 此处由于在判断应用未登录时也需要进行路由栈的变化，因此返回HMInterceptorAction.DO_REJECT，停止当前此次跳转的拦截和路由动作。

```extendtypescript
// 拦截器，判断登录状态，决定是否跳转到登录页面登录之后才能查看详细信息
@HMInterceptor({ interceptorName: 'LoginInterceptor' })
export class LoginInterceptor implements IHMInterceptor {
  handle(info: HMInterceptorInfo): HMInterceptorAction {
    if (!AppStorage.get('isLogin') && info.isSrc === false) {
      info.context.getPromptAction().showToast({ message: '请先登录' });
      HMRouterMgr.push({ pageUrl: 'LoginPage', param: info.routerPathInfo }, {
        onResult: (popInfo: HMPopInfo) => {
          if (popInfo.result === true) {
            HMRouterMgr.push(info.routerPathInfo, info.routerPathCallback);
          }
        }
      });
      return HMInterceptorAction.DO_REJECT;
    } else {
      return HMInterceptorAction.DO_NEXT;
    }
  }
}

// 需要登录才能查看的信息页面
@HMRouter({ pageUrl: 'HMInterceptor://Mine', interceptors: ['LoginInterceptor'] })
@Component
export struct InterceptorCases {
  
  build() {
    Flex() {}
  }
}
```

```extendtypescript
// 登录页面
@HMRouter({ pageUrl: 'LoginPage', dialog: true })
@Component
export struct LoginPage {
  
  build() {
    Flex(){
      Button(LoginConstants.LOGIN_BUTTON)
        .width('90%')
        .height($r('app.float.cell_min_height'))
        .fontColor($r('app.color.color_white'))
        .backgroundColor($r('app.color.text_blue'))
        .margin({ left: 15, right: 10, bottom: 15 })
        .onClick(() => {
          AppStorage.set('isLogin', true);
          HMRouterMgr.pop({ param: true });
        })
    }
  }
}
```

## 生命周期配置使用场景
### 组件内监听页面生命周期
在自定义子组件内，需要监听页面显示，隐藏或者页面手势返回时，可以通过提供的`addObserver`方法注册监听
```extendtypescript
@Component
struct ChildComponent {
  @State backPressCount: number = 0;

  aboutToAppear(): void {
    HMRouterMgr.getCurrentLifecycleOwner()?.addObserver(HMLifecycleState.onBackPressed, () => {
      this.showToast();
      this.backPressCount++;
      return true;
    });
  }
  // 组件内定义的方法
  showToast() {
    this.getUIContext().getPromptAction().showToast({ message: '组件内定义的弹窗方法' });
  }
}

@HMRouter({ pageUrl: 'AddObserveCase' })
@Component
export struct AddObserverCases {

  build() {
    Flex() {
      ChildComponent()  // 子组件内容
    }
  }
}
```
### 两次返回退出应用

首页退出应用时，第一次返回时提示“再次返回退出应用”，再次返回时应用真正退出，可以通过生命周期的onBackPressed处理

```extendtypescript
@HMLifecycle({ lifecycleName: 'BackPressLifecycle' })
export class BackPressLifecycle implements IHMLifecycle {
  private lastTime: number = 0;

  onBackPressed(ctx: HMLifecycleContext): boolean {
    let time = Date.now();
    if (time - this.lastTime > 1000) {
      ctx.uiContext.getPromptAction().showToast({ message: '再次返回退出页面', duration: 1000 });
      this.lastTime = time;
      return true;
    } else {
      return false;
    }
  }
}

@HMRouter({ pageUrl: 'BackPressCase', lifecycle: 'BackPressLifecycle' })
@Component
export struct BackPressCase {
  
}
```

### 页面打点

配置全局生命周期用于页面打点，计算耗时等统计分析；全局生命周期配置需要配置`global: true`，不需要和页面之间建立绑定关系

```extendtypescript
@HMLifecycle({ lifecycleName: 'GlobalLifecycle', global: true, priority: 100 })
export class CasesLifecycle implements IHMLifecycle {
  private time: number = 0;
  private logString: string = '';

  onShown(ctx: HMLifecycleContext): void {
    this.time = new Date().getTime();
  }

  onHidden(ctx: HMLifecycleContext): void {
    const duration = new Date().getTime() - this.time;
    Logger.info(`页面${ctx.navContext?.pathInfo.name}显示时长${duration / 1000}s`);
    this.logString += `页面${ctx.navContext?.pathInfo.name}显示时长${duration / 1000}s \n`;
    AppStorage.setOrCreate('PageLog', this.logString);
  }
}
```

### 页面UI中获取生命周期示例内定义的数据
生命周期实例中可以初始化对象，并且在UI组件中获取做为状态变量
```extendtypescript
@HMLifecycle({lifecycleName: 'exampleLifecycle'})
export class ExampleLifecycle implements IHMLifecycle {
  model: ObservedModel = new ObservedModel();
}

@Observed
export class ObservedModel {
  isLoad: boolean = false;
  bizModel?: Data;
}

@HMRouter({pageUrl:'PageOne', lifecycle:'exampleLifecycle'})
@Component
struct PageOne {
  @State model: ObservedModel | null = (HMRouterMgr.getLifecycleOwner().getLifecycle() as ExampleLifecycle).model;
}
```

### 提前发起网络请求，获取接口数据

在onPrepare生命周期回调中提前发起网络请求，实现网络请求与页面跳转并行化，可以优化页面跳转的响应时延、完成时延

> 对比在aboutToAppear生命周期中发起网络请求，使用onPrepare进行预加载可以优化5-20ms

```extendtypescript
@HMLifecycle({ lifecycleName: 'HttpCaseLifecycle' })
@Observed
export class CasesLifecycle implements IHMLifecycle {
  isRequestFinished: boolean = false;
  id: string = '';
  onPrepare(ctx: HMLifecycleContext): void {
    const params = HMRouterMgr.getCurrentParam(HMParamType.urlParam) as Map<string, string>;
    // 模拟数据异步请求
    setTimeout(() => {
      ctx.uiContext.getPromptAction().showToast({ message: `页面参数：${params?.get('id')}，数据请求成功` });
      this.id = params?.get('id') as string;
      this.isRequestFinished = true;
    }, 3000);
  }
}

@HMRouter({ pageUrl: 'HttpCase', lifecycle: 'HttpCaseLifecycle' })
@Component
export struct LifecycleCases {
  @State viewModel: CasesLifecycle = HMRouterMgr.getCurrentLifecycleOwner()?.getLifecycle() as CasesLifecycle;

}
```

## 转场动画配置使用场景

[动画原理及详细使用说明](./CustomTransition.md)

### 全局自定义转场

在创建HMNavigation组件时，可以配置全局自定义转场效果，当前提供direction、scale、opacity供开发者配置

```extendtypescript
export class HMCustomGlobalAnimator {
  // 标注页面转场动画
  static STANDARD_ANIMATOR: IHMAnimator.Effect = new IHMAnimator.Effect({
    direction: IHMAnimator.Direction.BOTTOM_TO_TOP,
    opacity: { opacity: 0.5 }
  });
  // 弹窗类型页面动画
  static DIALOG_ANIMATOR: IHMAnimator.Effect = new IHMAnimator.Effect({
    scale: {
      centerX: '50%',
      centerY: '50%',
      x: 0.5,
      y: 0.5
    },
    opacity: { opacity: 0.2 }
  });
}

@HMRouter({ pageUrl: 'animator://globalAnimatorPage' })
@Component
export struct GlobalAnimatorPage {
  build() {
    Flex() {
      HMNavigation({
        navigationId: 'childNavigation',
        homePageUrl: 'GlobalAnimatorHomePage',
        options: {
          standardAnimator: HMCustomGlobalAnimator.STANDARD_ANIMATOR,
          dialogAnimator: HMCustomGlobalAnimator.DIALOG_ANIMATOR
        }
      })
    }
  }
}
```

### 特定页面自定义转场

通过定义@HMRouter页面时，指定animator动画名称，绑定页面动画效果

```extendtypescript
@HMAnimator({ animatorName: 'liveCommentsAnimator' })
@HMAnimator({ animatorName: 'customAnimator' })
export class CustomAnimator implements IHMAnimator {
  effect(enterHandle: HMAnimatorHandle, exitHandle: HMAnimatorHandle): void {
    enterHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '100%';
      opacityOption.opacity = 0.4;
    });
    enterHandle.finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '0';
      opacityOption.opacity = 1;
    });
    enterHandle.onFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '0';
      opacityOption.opacity = 1;
    });

    exitHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '0';
      opacityOption.opacity = 1;
    });
    exitHandle.finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '100%';
      opacityOption.opacity = 0.4;
    });
    exitHandle.onFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.y = '0';
      opacityOption.opacity = 0.4;
    });
  }
}

@HMRouter({ pageUrl: 'animator://customAnimator', animator: 'customAnimator' })
@Component
export struct CustomAnimatorPage {
}
```

### 特定页面支持交互式(跟手)转场

HMRouter提供了交互式(跟手)转场的接入，开发者可轻松实现交互式(跟手)转场效果。

通过`effect`方法配置入场和出场状态，通过`interactive`方法配置交互式手势事件

```extendtypescript
@HMAnimator({ animatorName: 'interactiveAnimator' })
export class InteractiveAnimator implements IHMAnimator {
  effect(enterHandle: HMAnimatorHandle, exitHandle: HMAnimatorHandle): void {
    enterHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '100%';
      opacityOption.opacity = 0.4;
    });
    enterHandle.finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '0';
      opacityOption.opacity = 1;
    });
    enterHandle.onFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '0';
      opacityOption.opacity = 1;
    });

    exitHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '0';
      opacityOption.opacity = 1;
    });
    exitHandle.finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '100%';
      opacityOption.opacity = 0.4;
    });
    exitHandle.onFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      translateOption.x = '0';
      opacityOption.opacity = 0.4;
    });
  }

  interactive(handle: HMAnimatorHandle): void {
    handle.actionStart((event: GestureEvent) => {
      if (event.offsetX > 0) {
        HMRouterMgr.pop();
      }
      handle.startOffset = event.fingerList[0].localX;
    });
    handle.updateProgress((event, proxy, operation, startOffset) => {
      if (!proxy?.updateTransition || !startOffset) {
        return;
      }
      let offset = 0;
      if (event.fingerList[0]) {
        offset = event.fingerList[0].localX - startOffset;
      }
      if (offset < 0) {
        proxy?.updateTransition(0);
        return;
      }
      let rectWidth = event.target.area.width as number;
      let rate = offset / rectWidth;
      proxy?.updateTransition(rate);
    });
    handle.actionEnd((event, proxy, operation, startOffset) => {
      if (!startOffset) {
        return;
      }
      let rectWidth = event.target.area.width as number;
      let rate = 0;
      if (event.fingerList[0]) {
        rate = (event.fingerList[0].localX - startOffset) / rectWidth;
      }
      if (rate > 0.4) {
        proxy?.finishTransition();
      } else {
        proxy?.cancelTransition?.();
      }
    });
  }
}

@HMRouter({ pageUrl: 'animator://InteractiveAnimator', animator: 'interactiveAnimator' })
@Component
export struct InteractiveAnimatorPage {
  
}
```

### 根据条件选择不同转场

相同的页面可能在不同表现情况下出现不同的转场效果，开发者需要在进行路由跳转时，根据当前视频状态提供不同的转场自定义动画，通过push时的animator属性传入指定转场，当传入`animator: false`页面跳转将无动画效果。

```extendtypescript
export class OnceAnimator implements IHMAnimator {
  effect(enterHandle: HMAnimatorHandle, exitHandle: HMAnimatorHandle): void {
    enterHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 0;
      translateOption.x = '100%';
    }).finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 1;
      translateOption.x = '0%';
    }).passiveStart((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 0;
      translateOption.x = '-100%';
    }).passiveFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 1;
      translateOption.x = '0%';
    });
    enterHandle.duration = 1000;
    enterHandle.timeout = 1000; // timeout 需要大于等于 duration

    exitHandle.start((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 1;
      translateOption.x = '0%';
    }).finish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 0;
      translateOption.x = '100%';
    }).passiveStart((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 1;
      translateOption.x = '0%';
    }).passiveFinish((translateOption: TranslateOption, scaleOption: ScaleOption,
      opacityOption: OpacityOption) => {
      opacityOption.opacity = 0;
      translateOption.x = '-100%';
    })
    exitHandle.duration = 1000;
    exitHandle.timeout = 1000; // timeout 需要大于等于 duration
  }
}

@HMRouter({ pageUrl: 'animator://OnceAnimator' })
@Component
export struct OnceAnimatorPage {
  build() {
    Column() {
      // 通过push方法传入自定义动画，一次性生效。
      Button(`打开其他页面 动画：${this.enableAnimator ? '使用指定动画' : '无动画'}`)
        .onClick(() => {
          HMRouterMgr.push({ pageUrl: 'MainPage', animator: this.enableAnimator ? new OnceAnimator() : false });
        });
    }
  }
}
```

从上面一段代码可以看出，开发者需要自定义两种不同的转场效果，如果此转场动画未被其他组件使用，则可以不需要使用@HMAnimator声明，但是必须实现IHMAnimator接口，
指定的主动入场和出场动画针对目标页面生效，被动的入场和出场动画针对发起页面生效。

## 一次开发多端部署

### HMNavigation分栏

`HMRouter`是在`Navigation`上的封装，因此通过`HMNavigation`可以实现`Navigation`的分栏效果。
实现分栏效果，只需要在配置`HMNavigation`时指定`modifier`的mode，默认未指定时mode为`NavigationMode.Auto`，界面将自动决定是否分栏，NavigationMode.Auto情况下折叠屏展开状态时，将分栏展示，折叠屏折叠状态时，默认不分栏；
可以修改mode的属性，制定界面是否强制分栏或者不分栏，`NavigationMode.Split`为分栏展示，`NavigationMode.Stack`不分栏，导航栏和内容独立显示，相当于两个页面
此时`HMNavigation`闭包中的内容为左分栏内容，传入pageUrl为默认右分栏内容。

```extendtypescript
class LayoutModifier extends AttributeUpdater<NavigationAttribute> {
  initializeModifier(instance: NavigationAttribute): void {
    instance.backgroundColor('#EFEFEF');
    instance.mode(NavigationMode.Auto);
  }
}

@HMRouter({ pageUrl: 'Layout://NavigationLayout' })
@Component
export struct NavigationLayout {
  navigationId = 'NavigationLayoutNavigationId';
  modifier: LayoutModifier = new LayoutModifier();
  
  build() {
    HMNavigation({
      navigationId: this.navigationId,
      options: {
        modifier: this.modifier
      }
    }) {
      NavBarContent()
    };
  }
}
```

### NavBar首页内容监听页面生命周期

当前HMNavigation使用闭包，NavBar跳转到NavDestination页面时，没有自定义生命周期方式处理，可以通过`HMRouterMgr.getCurrentLifecycleOwner().addObserver`方法，添加到NavBar对应生命周期内。

```extendtypescript
@Component
export struct NavBarContent {

  aboutToAppear(): void {
    const owner = HMRouterMgr.getCurrentLifecycleOwner();
    // 拦截navbar页面退出场景
    owner?.addObserver(HMLifecycleState.onBackPressed, (ctx) => {
      if (this.reConfirm === false) {
        this.reConfirm = true;
        setTimeout(() => {
          this.reConfirm = false;
        }, 1500)
        ctx.uiContext.getPromptAction().showToast({
          message: '再次返回退出页面',
          duration: 1500
        })
        return true;
      } else {
        return false
      }
    })
  }
  
  build() {
    //...
  }
}

@HMRouter({ pageUrl: 'demo://NavbarLifecycleInDst' })
@Component
export struct NavBarLifecycleInDst {
  navigationId = 'NavBarLifecycleInDst';
  
  build() {
    Flex() {
      HMNavigation({ navigationId: this.navigationId }) {
        NavBarContent({
          NavBarDesc: this.NavBarDesc,
          hideTitle: true
        })
      }
    }
  }
}
```
**注意事项**：为了使NavBar通过addObserver注册的回调可以监听到@Entry页面生命周期触发，需要在Page页面中调用HMRouterMgr.generatePageLifecycleId和HMRouterMgr.getPageLifecycleById方法，采用如下述处理方式：  
在@Entry页面初始化时生成pageLifecycleId，在页面对应生命周期内，通过pageLifecycleId触发对应方法。
```extendtypescript
@Entry({ routeName: 'NavBarLifecycleInPage' })
@Component
export struct NavBarLifecycleInPage {
  navigationId = 'NavBarLifecycleInPage';
  private pageLifecycleId: string = HMRouterMgr.generatePageLifecycleId();
  
  onPageShow(): void {
    HMRouterMgr.getPageLifecycleById(this.pageLifecycleId)?.onShown();
  }
  
  onPageHide(): void {
    HMRouterMgr.getPageLifecycleById(this.pageLifecycleId)?.onHidden();
  }
  
  aboutToDisappear(): void {
    HMRouterMgr.getPageLifecycleById(this.pageLifecycleId)?.onDisAppear();
  }
  
  onBackPress(): boolean {
    return HMRouterMgr.getPageLifecycleById(this.pageLifecycleId)?.onBackPressed() as boolean;
  }
  
  build() {
    Flex() {
      HMNavigation({ navigationId: this.navigationId }) {
        NavBarContent({
          NavBarDesc: this.NavBarDesc,
          hideTitle: true
        });
      }
    }
  }
}
```

## 自定义模板
自定义模板主要提供生成路由NavDestination页面自定义能力，关于自定义模板的配置可参考[自定义模板配置](./CustomTemplate.md)

### 修改全局页面模板，显示页面标题
HMRouter生成的路由页面默认时关闭`NavDestination`的`title`，如果我们想使用NavDestination提供的默认标题可以通过修改自定义模板的方式删除`.hideTitleBar(true)`配置，
具体模板配置可以参考[显示页面标题](../HMRouterExamples/features/custom_template_cases/src/main/templates/TitleBarTemplate.ejs)


### 弹窗类型页面添加弹窗背景蒙层
使用HMRouter默认模板生成的弹窗类型页面，无法实现弹窗蒙层和内容的显示动画分离，需要通过自定义模板的方式，将弹窗的动画属性`translate(this.translateOption), scale(this.scaleOption), opacity(this.opacityOption.opacity)`添加到内层组件，外层父组件添加蒙层样式，具体配置可以参考[弹窗添加蒙层](../HMRouterExamples/features/custom_template_cases/src/main/templates/DialogMaskTemplate.ejs)

```ejs
NavDestination() {
  Stack({alignContent:Alignment.Bottom}) {
    <%= componentName %>()
  }.translate(this.translateOption)     // 内层动画控制属性设置
  .scale(this.scaleOption)              // 内层动画控制属性设置
  .opacity(this.opacityOption.opacity)  // 内层动画控制属性设置
  .width('100%')
  .height('100%')
}
.backgroundColor(this.colorOption.color) // 外层的蒙层设置
```

### 界面内手势操作和模板手势事件冲突
当界面内存在手势操作场景，例如界面存在地图和横向的滚动列表情况下，这时候会出现界面内手势操作不生效问题，是由于界面内的手势操作和默认模板内绑定的手势事件导致
需要通过自定义模板方式，删除模板内绑定的手势事件，具体模板修改可以参考[模板手势事件处理](../HMRouterExamples/features/custom_template_cases/src/main/templates/GestureTemplate.ejs)
如当前页面中也存在手势动画的场景，可在页面中自行定义手势动画触发，具体使用可参考[横向列表手势动画](../HMRouterExamples/features/custom_template_cases/src/main/ets/pages/gesture/ListCase.ets)

> 查看地图示例需要应用开通地图服务并手动签名，具体步骤参考：
> 
> 1.应用开通地图服务具体操作流程见[地图服务开发准备](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V5/map-config-agc-V5)
> 
> 2.根据在AGC网站创建的应用，修改工程内的包名，使其能正常签名，应用包名修改需要修改`AppScope/app.json5`文件下的`bundleName`
> 
> 3.应用开通服务之后，需要根据应用申请调试证书对样例工程进行签名，参考[应用/服务手动签名](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V5/ide-signing-V5#section297715173233)

## 服务路由
###  HMService服务定义与调用
服务路由通过`@HMService`定义，`@HMService`仅支持装饰类的方法，支持同步和异步以及传参的方式

定义服务路由：
```extendtypescript
export class CustomService {
  @HMService({serviceName: 'testConsole'})
  testConsole(): void {
    Logger.info('Calling service testConsole');
  }

  @HMService({serviceName: 'testFunWithReturn'})
  testFunWithReturn(): string {
    return 'Calling service testFunWithReturn';
  }

  @HMService({serviceName: 'testFunWithParams', singleton: true})
  testFunWithParams(str: string, num: number, bool: boolean, obj: TempObj) {
    Logger.info('The 1st parameter of service testFunWithParams: ' + str);
    Logger.info('The 2nd parameter of service testFunWithParams: ' + num);
    Logger.info('The 3rd parameter of service testFunWithParams: ' + bool);
    Logger.info('The 4th parameter of service testFunWithParams: ' + JSON.stringify(obj));

    return obj.paramA || obj.paramB;
  }

  // Define asynchronous services, where the service name and function name can be different
  @HMService({serviceName: 'testAsyncFun', singleton: true})
  async testAsyncFunction(): Promise<string> {
    return new Promise((resolve) => {
      resolve('Calling asynchronous service testAsyncFun');
    });
  }
}
```
页面内调用服务路由通过HMRouterMgr.request的方式
```extendtypescript
@HMRouter({ pageUrl: 'Service://ServiceLoader' })
@Component
export struct ServiceLoader {
  @State logString: string = '';

  build() {
    Flex() {
      Button('无返回值调用')
        .onClick(() => {
          HMRouterMgr.request('testConsole');
          this.logString = 'testConsole';
        });
      Button('有返回值调用')
        .onClick(() => {
          const result = HMRouterMgr.request('testFunWithReturn');
          this.logString = 'ServiceLoader 有返回值调用: ' + JSON.stringify(result);
        });
      Button('带参数调用')
        .onClick(() => {
          const obj: TempObj = {
            paramA: 'paramA',
            paramB: 100
          };
          const result = HMRouterMgr.request('testFunWithParams', 'testStr', 10, false, obj);
          this.logString = 'ServiceLoader 带参数调用返回值: ' + JSON.stringify(result);
        });
      Button('异步调用')
        .onClick(() => {
          HMRouterMgr.request('testAsyncFun').data.then((data: string) => {
            this.logString = 'ServiceLoader 异步调用:' + data;
          });
        });
    }.width('100%').height('100%');
  }
}
```

## 混淆使用场景
当前模块混淆配置为true，编译release包的时候，会开启混淆
```json5
{
  "buildOptionSet": [
    {
      "name": "release",
      "arkOptions": {
        "obfuscation": {
          "ruleOptions": {
            "enable": true,
            "files": [
              "./obfuscation-rules.txt"
            ]
          }
        }
      }
    },
  ],
}
```
### 自动配置混淆白名单
在当前模块`hmrouter_config.json`中配置`autoObfuscation`为true，即可自动生成混淆白名单文件，并加入到混淆配置中
```json
{
  "autoObfuscation":true
}
```
### 手动配置混淆白名单
当前模块`hmrouter_config.json`中配置`autoObfuscation`为false，或者不配置，编译插件会自动生成`hmrouter_obfuscation_rules.txt`文件，根据该文件将混淆白名单配置到`obfuscation-rules.txt`中，即可手动配置混淆白名单。也可以根据[HMRouter配置混淆白名单](https://gitee.com/hadss/hmrouter/wikis/HMRouter%E6%B7%B7%E6%B7%86%E9%85%8D%E7%BD%AE)手动配置