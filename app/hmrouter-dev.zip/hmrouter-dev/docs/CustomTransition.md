# 自定义转场动画使用说明

## 接口定义

[查看详情](./Reference.md#ihmanimator-自定义转场动画接口)

## 原理介绍

开发者通过实现`IHMAnimator`接口，覆盖`effect`和`interactive`方法，来对动画效果进行自定义

动画效果处理器`HMAnimatorHandle`在页面加载`aboutToAppear`时进行初始化，对动画效果进行预设，并在页面跳转时进行调用

一次性动画的处理器会在页面跳转时进行重新覆盖

因此需注意:

- 全局动画的变更不会影响到已经加载的页面(包括单例页面)，只有页面重新加载才会生效

### 动画状态设置

`effect(enterHandle: HMAnimatorHandle, exitHandle: HMAnimatorHandle)`方法中提供了入场动画`enterHandle`和出场动画`exitHandle`2组动画状态设置

通过对`HMAnimatorHandle`回调中的页面位移/缩放/透明度等状态进行设置，来实现动画效果

- 入场动画分为主动入场`enterHandle.start/finish/onFinish`和被动入场`enterHandle.passiveStart/passiveFinish/passiveOnFinish`

- 出场动画分为主动出场`exitHandle.start/finish/onFinish`和被动出场`exitHandle.passiveStart/passiveFinish/passiveOnFinish`

每种动画可以设置3种页面状态:

- 动画开始状态`start`
- 动画完成状态`finish`
- 动画结束状态`onFinish`

通过设置动画曲线让页面在开始和完成状态之间进行过渡，默认动画曲线为`Curve.EaseIn`，结束状态用于将页面还原，释放资源等

**A页面push/replace到B页面**：B页面为主动入场，A页面为被动出场

![push](assets/CustomTransitionExplain-Push.jpg)

**B页面pop到A页面**：B页面为主动出场，A页面为被动入场

![pop](assets/CustomTransitionExplain-Pop.jpg)

动画曲线、持续时间、超时时间等也需要通过`HMAnimatorHandle`进行设置

`HMAnimatorHandle`也提供了自定义动画回调`customAnimation`和`passiveCustomAnimation`让开发者对动画进行完全控制

**自定义动画类型**:

- 全局自定义动画通过`HMNavigation`初始化时定义，并且可以通过`HMRouterMgr`进行修改
- 页面自定义动画通过`@HMRouter`标签进行定义，页面跳转时分别执行2个页面定义的动画，如果有页面未定义则使用全局动画
- 一次性动画通过`HMRouterMgr`进行页面跳转时定义，同时执行一次性动画中的入场动画和出场动画

一次性动画的覆盖原则:
> - 路由push/replace时传入一次性动画，目标页面执行一次性动画的主动入场，源页面执行一次性动画的被动离场；
> - push/replace时传入的一次性动画根据目标页面生存周期，当目标页面pop时未传入一次性动画，则执行push/replace时的一次性动画，pop目标页面执行一次性动画的被动入场，源页面执行主动离场
> - 当pop时传入一次性动画，目标页面的被动入场和源页面的主动离场均查找一次性动画
> - 上述场景描述的主动入场，被动入场，主动离场，被动离场动画，如果一次性动画内未定义，则会执行页面定义的动画或者全局动画定义

### 交互式事件配置

`interactive?(handle: HMAnimatorHandle)`方法中提供了交互式事件配置

通过对`HMAnimatorHandle`回调中的手势事件回调来进行路由操作，实现动画状态的跟随手势变化

手势事件：

- `actionStart`: 手势开始事件，在事件中触发路由跳转，通过对手势位移判断来决定页面是push/replace还是pop
- `updateProgress`: 手势更新事件，在事件中通过设置转场进度百分比来触发动画曲线的跟随手势变化
- `actionEnd`: 手势结束事件，在事件中对手势位移判断来调用`NavigationTransitionProxy`决定转场状态是完成转场还是取消转场

交互式转场方法`interactive`不设置动画效果，只是通过手势事件对转场行为进行处理并控制动画曲线的进度，动画效果需要配合`effect`方法进行定义




