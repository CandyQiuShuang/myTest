# HMRouterTransitions接口和属性列表

## HMRouterTransitions类

提供初始化，以及获取一镜到底动画方法

| 接口                  | 参数                                                                                         | 返回值                      | 接口描述                                                                                                                 |
|---------------------|--------------------------------------------------------------------------------------------|--------------------------|----------------------------------------------------------------------------------------------------------------------|
| static init         | windowStage: window.WindowStage                                                            | void                     | 初始化方法，将windowStage窗口对象存储，获取窗口尺寸信息                                                                                    |
| static cardLongTake | clickedComponentId: string, targetComponentId: string, options?: LongTakeTransitionOptions | IHMAnimator \| undefined | 获取一镜到底页面动画: clickedComponentId：对应起始页面的卡片id, targetComponentId是目标页面和卡片显示内容相近的组件id, LongTakeTransitionOptions说明见下述表格内容 |

## LongTakeTransitionOptions接口

一镜到底动画从开始到结束时的回调

| 接口                | 参数 | 返回值  | 接口描述                    |
|-------------------|----|------|-------------------------|
| onTransitionStart | 空  | void | 一镜到底动画开始回调，从A->B动画开始时执行 |
| onTransitionEnd   | 空  | void | 一镜到底动画结束回调，从B->A动画结束后执行 |