# HMRouterTransitions常见问题

## 1.使用一镜到底动画时，页面跳转时没有动画效果

需要排查目标页面是否使用了自定义模板，目标页面需要配置`HMRouterTransitions`库提供的模板；

通过[HMRouter自定义模板](./CustomTemplate.md)能力配置一镜到底页面模板

```json5
{
  "customPageTemplate": [
    {
      "srcPath": [
        "**/CardLongTakePageTwo.ets" // 一镜到底目标页面
      ],
      "templatePath": "./oh_modules/@hadss/hmrouter-transitions/ets/template/CardLongTakeTemplate.ejs" // HMRouterTransitions提供的模板地址
    }
  ]
}
```

## 2.页面跳转到目标页面时，执行的动画是系统默认动画，不是一镜到底动画

需要排查页面跳转时，使用`HMRouterTransitions.cardLongTake`方法获取的结果是否为空，当为空时，需要查看`hilog`日志排查错误原因，错误日志信息可以通过`RouterTransitions`关键字过滤  
当前可能导致接口返回空的原因有：

1.应用入口未调用`HMRouterTransitions.init(windowStage)`完成初始化，报错信息：`HMRouterTransitions is not init，WindowUtils.window is undefined`；

2.传入的参数无效，报错信息:`clickedComponentId is invalid, snapShotImage or longTakeArea is Empty`； 
第二个参数不直接影响`HMRouterTransitions.cardLongTake`是否返回未空，但是会影响动画的计算；
