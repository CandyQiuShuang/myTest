# HMRouter常见问题

# 编译期常见问题

## **正常编译通过的场景**

  一次正常的编译应该包含如下两个任务`HMRouterPluginTask,CopyRouterMapToRawFileTask`以及相关的编译日志

1.描述本工程中有哪些模块配置了插件任务
   

![image-20240905152545964](../docs/assets/image-20240905152545964.png)

2.`HMRouterPluginTask`任务执行日志，描述当前模块中扫描了哪些文件，生成了哪些文件，当前任务执行耗时打点

![image-20240905151944060](../docs/assets/image-20240905151944060.png)

3.`CopyRouterMapToRawFileTask`任务执行日志

![image-20240905152941819](../docs/assets/image-20240905152941819.png)

4.任务执行结束删除生成产物，如果配置文件中`saveGeneratedFile`为`true`，则不删除当前模块生成产物
   

![image-20240905152150754](../docs/assets/image-20240905152150754.png)

  每一次正常的编译，每个模块都应该包含上面的日志



## **常见异常场景**

1.装包失败场景

下面为正常装包成功的日志
    
![image-20240905153432244](../docs/assets/image-20240905153432244.png)
    
场景异常场景有如下几种：
    

* 版本号错误，如下所示日志，检查版本号即可
  

![image-20240905162729406](../docs/assets/image-20240905162729406.png)
    
* npm镜像无效，出现xxx Not Found - 404一般为npm镜像无效问题，建议按照[官网镜像](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V5/ide-environment-config-V5#section197296441787)配置
  

![image-20240905162936628](../docs/assets/image-20240905162936628.png)

2.编译失败场景
   

插件有几种异常检测会主动抛出异常，详情请见[错误码](./Reference.md#错误码)，如出现如下类似的系统错误日志，请检查下IDE版本，目前已知Build Version: 5.0.3.600版本会偶现该问题，可升级版本解决
    
```txt
hvigorERROR: Duplicate 'routerMap' object names detected.
     
* Try the following:
> Change the 'routerMap' object names listed below under routerMap in the respective router configuration files. Make sure the names are unique across the current module and the modules on which it depends.
{"home":["BootView"]}
```



# 运行时常见问题

插件编译通过，启动app出现白屏

  首先排除编译日志，是否是一次正常的编译，如果缺失某些日志，可能是插件配置错误，请检查模块的`hvigorfile.ts`文件是否正确配置

  ![image-20240905164731214](../docs/assets/image-20240905164731214.png)

页面正常加载，正常跳转，生命周期/拦截器/动画无效

  打开`hilog`日志，观察是否出现如下异常

  ![image-20240905165059890](../docs/assets/image-20240905165059890.png)

  如出现，请检查工程级别的`build-profile.json5`文件配置，红框标注的配置项必选

  ![image-20240905165213069](../docs/assets/image-20240905165213069.png)
页面正常加载，正常跳转，部分生命周期/拦截器/动画无效



打开hilog日志，观察是否出现如下异常，关键错误码**40005008**

```text
[HMRouter ERROR]ERR_DYNAMIC_IMPORT_FAILED 40005008 动态加载失败 - entry/src/main/ets/lifecycle/WelcomeLifecycle - com.huawei.hadss.hmrouter/entry - WelcomeLifecycle
```
![dynamic import](../docs/assets/image-20240907164902.png)

如果出现，请检查对应的类是否导出
![dynamic import](../docs/assets/image-20240907165317.png)



# 常见错误码及排查方法

## 错误码:40005008
表示使用动态加载的时候出现问题，请检查下面的配置是否正确
1.build-profile.json5中需要将useNormalizedOHMUrl配置为true
2.根据hilog找到对应的动态加载失败的代码位置，查看对应的类是否导出

如果错误未在上面的场景中列出，请参考动态加载原理中 **1.3 HMRouter动态加载**  章节原理进行排查
[动态加载原理](https://gitee.com/hadss/hmrouter/wikis/HMRouter%E5%8A%A8%E6%80%81%E5%8A%A0%E8%BD%BD%E5%8E%9F%E7%90%86%E4%BB%8B%E7%BB%8D)



# FAQ

## 问题:是否支持启动框架初始化HMRouter
支持，需要升级到1.0.0release以上版本，详细使用文档请参考。
[启动框架使用介绍](https://gitee.com/hadss/hmrouter/wikis/%E5%A6%82%E4%BD%95%E5%9C%A8%E5%90%AF%E5%8A%A8%E6%A1%86%E6%9E%B6%E4%B8%AD%E5%88%9D%E5%A7%8B%E5%8C%96HMRouter)

## 问题:HMRouter中根容器是NavDestination,项目中原有的SettingPage的根容器也是NavDestination，无法展示返回按钮
当前HMRouter标签暂时无法与NavDestination共用，生成代码默认会hidetitlebar，如果需要使用原生NavDestination的属性，可以使用registerPageBuilder接口注册。

原始Issues地址[Issues](https://gitee.com/hadss/hmrouter/issues/IAOIFZ)

##  问题: 路由嵌套情况下，路由发生跳转时，不是所期望的路由栈

**建议措施**：当发生上述问题时，建议在路由操作时，传入需要跳转的路由栈对应的navigationId。

**问题原因**：HMRouter提供的push/pop/replace接口默认可以不用传navigationId；当工程中只有一个HMNavigation时，不传navigationId做路由跳转不会存在问题；而当存在路由嵌套情况下，使用HMRouter作为路由跳转时，如果不传navigationId，框架会通过规则去查找；

**当前规则**：框架会自动记录上一次push/pop/replace操作时，所触发的路由栈对应的navigationId, 以及创建HMNavigation时所传入的navigationId；当使用接口跳转且未传navigationId的情况下，会查找最近一次记录的navigationId。

## 问题：生命周期里面获取到的数据怎么传递给页面

可以通过**HMRouterMgr.getcurrentlifecycleowner?.getlifecycle**方法获取当前的生命周期实例来获取数据，参考如下的代码

```extendtypescript
 let model = (HMRouterMgr.getCurrentLifecycleOwner()?.getLifecycle() as ExitPayDialog).model
 model.pageUrl = this.pageUrl
```

## 问题：router替换HMRouter后sharedTransition属性失效了

HMRouter是对navigation进行的封装，sharedTransition应该配合router使用，navigation 页面切换不会生效，在navigation中应该使用[geometryTransition](https://developer.huawei.com/consumer/cn/doc/harmonyos-references-V5/ts-transition-animation-geometrytransition-V5)来实现相同的效果

## 问题：按照文档正常配置了 homePageUrl 启动后白屏

homePageUrl属性的设置是指navigation默认push的第一个NavDestination的页面路由，需要配合HMNavigation的hideNavBar属性一起使用才有效果，正确使用代码如下

```extendtypescript
class MyNavModifier extends AttributeUpdater<NavigationAttribute> {
  initializeModifier(instance: NavigationAttribute): void {
    // 配置hideNavBar让navigation不显示navbar页面，默认就显示第一个NavDestination的页面
    instance.hideNavBar(true)
  }
}

@Entry
@Component
struct Index {
  modifier: MyNavModifier = new MyNavModifier()

  build() {
    Column() {
      HMNavigation({
        navigationId: PageConstants.MAIN_NAVIGATION_ID, homePageUrl: PageConstants.MAIN_PAGE, options: {
          modifier: this.modifier
        }
      })
    }
    .height('100%')
    .width('100%')
  }
}
```

## 问题：push时传入了一次性动画实例，但是pop不生效

一次性动画是指**当次跳转的动画**，即当push时传入动画实例，则仅仅针对当前的push生效，pop不生效，如果是pop时传入动画实例，则当前的pop跳转生效，push不生效。

如果是想要某个页面特殊的动画效果，应该是在@HMRouter标签中传入animator参数来设置当前页面的动画

## 问题：如何指定LaunchMode

调用系统原生方法指定即可

```extendtypescript
HMRouterMgr.getPathStack('xxx')?.pushPath({ name: 'xxx' }, { launchMode: LaunchMode.POP_TO_SINGLETON })
```


## 问题：弹窗页面以及从弹窗跳转其他页面无动画

打开弹窗页面无动画，以及从弹窗页面跳转其他页面没有动画，是系统默认规格，可以通过使用HMNavigation时，配置options.standardAnimator和options.dialogAnimator配置路由默认动画值，为打开弹窗和弹窗跳转其他页面添加动画；
也可以通过配置页面动画，获取路由时传入一次性动画添加跳转时的动画

## 编译报错 Cannot read properties of undefined (reading 'getBuildMode')

检查项目中工程级hvigorfile.ts中 如果是
```extendtypescript
export { appTasks } from '@ohos/hvigor-ohos-plugin';
```
这个是老工程的写法，替换成新工程写法即可，代码如下：
```extendtypescript
import { appTasks } from '@ohos/hvigor-ohos-plugin';

export default {
  system: appTasks,  /* Built-in plugin of Hvigor. It cannot be modified. */
  plugins:[]         /* Custom plugin to extend the functionality of Hvigor. */
}
```

## 组件使用`default`导出时无法跳转页面/编译报错

出现该问题原因时在内置模版中组件的`import`方式为`import {xxx} from 'xxxx'`所以使用默认导出可能会出现编译报错，或者编译不报错但是跳转不生效的问题
**解决方案：**
1.取消组件默认导出
2.使用自定义默认模版解决

## 集成HMRouter后IDE无法使用热重载功能

出现该问题原因是因为编译时默认删除编译产物，而真实显示的页面在编译产物中，所以导致热重载找不到页面
**解决方案：**
在`hmrouter_config.json`配置中设置`saveGeneratedFile`字段为`true`，保留编译产物即可

## 无法使用预览器

由于HMRouter用到了native能力，只能使用页面级预览`@Preview`，不能使用预览器启动

**启用页面级预览解决方案：**
在`hmrouter_config.json`配置中设置`saveGeneratedFile`字段为`true`，保留编译产物

## 使用多target情况多时候无法打包app，出现编译报错`The "to" argument must be of type string. Received undefined`

**原因分析:**

编译插件在多target情况下会把每个target都编译一次，重复编译导致编译失败
**解决方案:**

确保一个`target`对应一个`product`, 不要出现多余的`target`定义，也不要有一个模块中多个`target`给一个`product`的情况
官网说明了**同一个module的不同target不能打包到同一个product中**

[定义product中包含的target](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V5/ide-customized-multi-targets-and-products-guides-V5#section7613106105114)

## 出现错误`HMRouter ERROR][HMRouterStore] not exist xxx in xxx`如何处理

**原因分析:**

出现该问题原因一般是生成的`hm_router_map.json`中没有对应的数据，即插件没有扫描到该文件

**排查步骤:**
1. 看编译产物中的`hm_router_map.json`是否有该字段
2. 定义`xxx`的模块有没有配置编译插件
3. 配置了插件看是否有`hmrouter_config.json`配置，检查`scanDir`字段是否覆盖到了定义`xxx`的文件

## 如何实现清空页面栈但是保留当前页面的场景

可以通过`HMRouterMgr.getPathStack()`方法获取系统的[NavPathStack](https://developer.huawei.com/consumer/cn/doc/harmonyos-references-V5/ts-basic-components-navigation-V5#navpathstack10)
调用系统`clear`方法清空页面，然后在通过`HMRouter.push()`跳转即可

## 如何启动页配置场景

# 其他问题

## 标签中常量使用规则
支持使用常量的标签属性如下
* `@HMRouter({pageUrl,interceptor,lifecycle,animator})`
* `@HMInterceptor({interceptorName})`
* `@HMLifecycle({lifecycleName})`
* `@HMAnimator({animatorName})`
* `@HMService({serviceName})`

支持的常量定义位置

* 本文件中的使用`const`定义或者`class`中的`static`静态变量
* 本模块中使用`const`定义或者`class`中的`static`静态变量
* 本项目的`har/hsp`源码依赖，使用`const`定义或者`class`中的`static`静态变量
* 远程`har/hsp`的二进制依赖

支持的导出形式：
```extendtypescript
// 本地依赖
// index.ets
export * from './Constants'

// Constants.ets
export const A = 'aaa'
export class AAA {
  static readonly B = 'bbb'
}

// 远程依赖
// index.d.ets
export * from './Constants'

// Constants.ets
export const A = 'aaa'
export class AAA {
  static readonly B = 'bbb'
}
```

引用示例：
```extendtypescript
import { A, AAA } from 'constants_har';

@HMRouter({pageUrl: A, interceptor:[AAA.B]})
        
@HMInterceptor({interceptorName: AAA.B})
```

**注意以下情况不支持：**

1.不支持嵌套依赖场景，

   > 例如 hapA依赖harB、harC；harB依赖harD
   >
   > 在hapA中可以拿到harB,harC的常量，harB中可以拿到harD的常量，但是hapA直接访问harD会编译报错

2.不支持别名导出场景

   > 例如
   >
   > common模块
   >
   > ```extendtypescript
   > // constants.ets
   > const AAA = 'aaa'
   > const BBB = 'bbb'
   > 
   > // index.ets
   > export {AAA as A, BBB} from './constants'
   > ```
   >
   > login模块
   >
   > ```extendtypescript
   > import {A,BBB} from 'common'
   > 
   > @HMRouter({pageUrl: A, lifecycle: BBB})
   > ```
   >
   > 上面的例子中A会报错找不到，因为在导出时使用了别名，BBB可以正常找到

3.不支持除string以外的其他常量类型

   > 例如在使用拦截器的时候可能存在多个拦截，代码如下
   >
   > ```extendtypescript
   > const INTERCEPTOR_A = 'interceptorA'
   > const INTERCEPTOR_B = 'interceptorB'
   > const INTERCEPTOR_C = 'interceptorC'
   > 
   > @HMInterceptor({interceptorName: INTERCEPTOR_A})
   > class interceptorA {}
   > @HMInterceptor({interceptorName: INTERCEPTOR_B})
   > class interceptorB {}
   > @HMInterceptor({interceptorName: INTERCEPTOR_C})
   > class interceptorC {}
   > 
   > // 在路由标签中使用正例
   > @HMRouter({interceptor:[INTERCEPTOR_A,INTERCEPTOR_B,INTERCEPTOR_C]})
   > // 反例
   > const INTERCEPTORS = [INTERCEPTOR_A,INTERCEPTOR_B,INTERCEPTOR_C]
   > @HMRouter({interceptor:INTERCEPTORS}) // 这里会报错提示无效的字符串常量
   > ```