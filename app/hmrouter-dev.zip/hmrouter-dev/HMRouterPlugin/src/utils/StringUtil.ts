export class StringUtil {
  /**
   * @description Get the hash value of the string
   * @param str: String that needs to be escaped
   * @returns Transformed hash value
   */
  static stringToHashCode(str: string): number {
    let hash = 0;
    if (str.length === 0) {
      return hash;
    }
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0; // Convert to a 32-bit integer
    }
    return hash;
  }
}
