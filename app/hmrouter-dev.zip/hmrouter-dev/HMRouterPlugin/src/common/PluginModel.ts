/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

export type AnalyzerResultLike =
  HMRouterResult
    | HMAnimatorResult
    | HMInterceptorResult
    | HMLifecycleResult
    | HMServiceResult;

export interface BaseAnalyzeResult {
  name?: string; // class name
  module?: string; // module name
  annotation?: string; // annotation
  pageSourceFile?: string; // File resource path
  isDefaultExport?: boolean; // Whether to export by default
}

export interface HMRouterResult extends BaseAnalyzeResult {
  pageUrl?: any; // Jump Path
  dialog?: boolean; // Whether to display a popup
  singleton?: boolean; // Whether it is a singleton
  interceptors?: string[]; // Interceptor array
  animator?: string; // animation
  lifecycle?: string; // lifecycle
}

export interface HMAnimatorResult extends BaseAnalyzeResult {
  animatorName?: string; // animator name
}

export interface HMInterceptorResult extends BaseAnalyzeResult {
  interceptorName?: string; // interceptor name
  priority?: number; // interceptor priority
  global?: boolean; // Whether it is a global interceptor
}

export interface HMLifecycleResult extends BaseAnalyzeResult {
  lifecycleName?: string; // lifecycle name
  priority?: number; // lifecycle priority
  global?: boolean; // Whether it is a global lifecycle
}

export interface HMServiceResult extends BaseAnalyzeResult {
  serviceName?: string; // service name
  functionName?: string; // function name
  singleton?: boolean; // Whether it is a singleton
}

export class TemplateModel {
  pageUrl: string;
  importPath: string;
  componentName: string;
  dialog: boolean;
  generatorViewName: string;
  isDefaultExport?: boolean;

  constructor(pageUrl: string, importPath: string, componentName: string, dialog: boolean, generatorViewName: string,
    isDefaultExport?: boolean) {
    this.isDefaultExport = isDefaultExport;
    this.pageUrl = pageUrl;
    this.importPath = importPath;
    this.componentName = componentName;
    this.dialog = dialog;
    this.generatorViewName = generatorViewName;
  }
}

export class RouterInfo {
  name: string;
  pageSourceFile: string;
  buildFunction: string;
  customData: AnalyzerResultLike;

  constructor(name: string, pageSourceFile: string, buildFunction: string, data: AnalyzerResultLike = {}) {
    this.name = name;
    this.pageSourceFile = pageSourceFile;
    this.buildFunction = buildFunction;
    this.customData = data;
  }
}
