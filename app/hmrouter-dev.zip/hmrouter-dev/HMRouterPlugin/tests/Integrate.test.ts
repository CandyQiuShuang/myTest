/*
 * Copyright (c) 2024 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {hvigor} from '@ohos/hvigor';
import {expect} from 'chai';
import HMFileUtil from '../src/utils/FileUtil';
import ejs from 'ejs';

describe('Integrate', () => {
  it('Annotation parse correct', () => {

  });
  it('should constFile', () => {
    let PageConstantStr = 'export default class PageConstants {\n';
    let lifecycleConstantStr = 'export default class LifecycleConstants {\n';
    let interceptorConstantStr = 'export default class InterceptorConstants {\n';
    for (let i = 1; i <= 1000; i++) {
      PageConstantStr += `\tstatic readonly PAGE_${i} = 'Page_${i}';\n`;
      lifecycleConstantStr += `\tstatic readonly Page${i}Lifecycle = 'Page${i}Lifecycle';\n`;
      interceptorConstantStr += `\tstatic readonly Page${i}Interceptor = 'Page${i}Interceptor';\n`;
    }
    PageConstantStr += '}';
    lifecycleConstantStr += '}';
    interceptorConstantStr += '}';
    let InterceptorFilePath = HMFileUtil.pathResolve(__dirname, './constant/InterceptorConstants.ets');
    HMFileUtil.ensureFileSync(InterceptorFilePath);
    HMFileUtil.writeFileSync(InterceptorFilePath, interceptorConstantStr);
    let lifecycleFilePath = HMFileUtil.pathResolve(__dirname, './constant/LifecycleConstants.ets');
    HMFileUtil.ensureFileSync(lifecycleFilePath);
    HMFileUtil.writeFileSync(lifecycleFilePath, lifecycleConstantStr);
    let PageFilePath = HMFileUtil.pathResolve(__dirname, './constant/PageConstants.ets');
    HMFileUtil.ensureFileSync(PageFilePath);
    HMFileUtil.writeFileSync(PageFilePath, PageConstantStr);
  });
  it('should PageFile', () => {
    const tpl = HMFileUtil.readFileSync(HMFileUtil.pathResolve(__dirname, './tpl/TestTemplate4.ets')).toString();
    for (let i = 1; i <= 1000; i++) {
      const templateStr = ejs.render(tpl, {index: i});
      let generatorFilePath = HMFileUtil.pathResolve(__dirname, `./pages/Page${i}.ets`);
      HMFileUtil.ensureFileSync(generatorFilePath);
      HMFileUtil.writeFileSync(generatorFilePath, templateStr);
    }
  });
});
