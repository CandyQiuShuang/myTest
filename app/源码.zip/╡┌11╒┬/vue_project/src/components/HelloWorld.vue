<template>
  <h1>hello Vue3</h1>
  <h1>
    当前的计数a：<span>{{ numa }}</span> <br />
    当前的计数b：<span>{{ numb }}</span> <br />
  </h1>
  <button @click="numa++">增加a</button>
  <button @click="numb++">增加b</button>
  <hr />
</template>

<script>
import { ref, reactive, watch, watchEffect } from "vue";
export default {
  name: "HelloWorld",

  setup() {
    let numa = ref(1);
    let numb = ref(1);

    // watch([numa, numb], (newValue, oldValue) => {
    //   console.log("numa或者numb变化了", newValue, oldValue);
    // });

    watchEffect(() => {
      // let xd = numa.value;
      // let xd1 = numb.value;
      console.log("watchEffect函数执行了");
    });

    return {
      numa,
      numb,
    };
  },
};
</script>

<style scoped>
span {
  color: red;
}
</style>
