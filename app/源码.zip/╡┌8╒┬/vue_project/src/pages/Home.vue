<template>
  <div>首页页面</div>
</template>

<script>
export default {};
</script>

<style scoped>
div {
  width: 200px;
  height: 200px;
  background-color: paleturquoise;
  line-height: 200px;
  text-align: center;
}
</style>
