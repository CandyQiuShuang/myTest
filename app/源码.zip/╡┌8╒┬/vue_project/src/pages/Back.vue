<template>
  <div>
    <div class="item">java<input type="text" /></div>
    <div class="item">php<input type="text" /></div>
    <div class="item">c++<input type="text" /></div>
  </div>
</template>

<script>
export default {};
</script>

<style>
.item {
  display: flex;
  justify-content: space-between;
}
input {
  width: 60px;
}
</style>