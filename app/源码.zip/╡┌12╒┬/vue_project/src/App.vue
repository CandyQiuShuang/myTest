<template>
  <HelloWorld />
</template>

<script>
import { ref, provide } from "vue";
import HelloWorld from "./components/HelloWorld.vue";

export default {
  name: "App",
  components: {
    HelloWorld,
  },
  setup() {
    let name = ref("小滴课堂");

    provide("xd", name);
  },
};
</script>

<style>
</style>
