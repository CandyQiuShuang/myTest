<template>
  <Grandson></Grandson>
</template>

<script>
import Grandson from "./Grandson.vue";
import { inject } from "vue";

export default {
  name: "HelloWorld",
  components: {
    Grandson,
  },
  setup() {
    console.log("儿子组件：", inject("xd"));
  },
};
</script>

<style scoped>
span {
  color: red;
}
</style>
