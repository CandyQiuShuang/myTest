<template>
  <div>
    <Counter />
    <hr />
    <hr />
    <Course />
  </div>
</template>

<script>
import Counter from "./components/Counter.vue";
import Course from "./components/Course.vue";

export default {
  name: "App",
  components: {
    Counter,
    Course,
  },
};
</script>

<style>
</style>
