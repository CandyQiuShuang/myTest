<template>
  <div>
    课程的列表：
    <ul>
      <li v-for="(i, index) in list" :key="index">{{ i.name }}</li>
    </ul>
    <h1>加工后的计数：{{ $store.getters.changeCount }}</h1>
    <button @click="xiajia">下架</button>
  </div>
</template>

<script>
export default {
  computed: {
    list() {
      return this.$store.state.list;
    },
  },
  methods: {
    xiajia() {
      this.$store.commit("XIAJIA");
    },
  },
};
</script>

<style>
</style>