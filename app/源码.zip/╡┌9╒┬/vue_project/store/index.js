import Vue from 'vue'; //引入Vue
import Vuex from 'vuex'; //引入Vuex
Vue.use(Vuex); //应用

export default new Vuex.Store({
  //接受用户的事件
  actions: {
    add(context, value) {
      context.commit('ADD', value);
    },
    reduce(context, value) {
      setTimeout(() => {
        context.commit('REDUCE', value);
      }, 1000);
    },
  },
  //操作state中的数据
  mutations: {
    ADD(state, value) {
      state.count += value;
    },
    REDUCE(state, value) {
      state.count -= value;
    },
    XIAJIA(state) {
      state.list.pop();
    },
  },
  //存放共享的数据
  state: {
    count: 0,
    list: [{ name: 'html' }, { name: 'css' }, { name: 'js' }],
  },
  getters: {
    changeCount(state) {
      return state.count * 2;
    },
  },
});
