<template>
  <div>
    <!-- <h1>{{ mess }}</h1> -->
    <!-- <hr />
    <HelloWorld msg="苹果" :transmit="transmit" /> -->

    <!-- 全局事总线 -->
    <!-- <hr />
    <FirstCustom @xd="handleChange" :list="list" />
    <hr />
    <SecondCustom ref="child" :deleteClick="deleteClick" /> -->

    <!-- 插槽 -->
    <!-- <SlotComponent>
      <template v-slot="{ list }">
        <div v-for="(i, index) in list" :key="index">{{ i }}</div>
      </template>
    </SlotComponent> -->
    <MixinComponent />
  </div>
</template>

<script>
// import HelloWorld from "./components/HelloWorld.vue";
// import FirstCustom from "./components/FirstCustom.vue";
// import SecondCustom from "./components/SecondCustom.vue";
// import SlotComponent from "./components/SlotComponent.vue";
import MixinComponent from "./components/MixinComponent.vue";

export default {
  name: "App",
  data() {
    return {
      mess: "",
      // list: ["苹果", "香蕉", "橙子"],
    };
  },
  components: {
    MixinComponent,
    // HelloWorld,
    // FirstCustom,
    // SecondCustom,
    // SlotComponent,
  },
  // methods: {
  //   transmit(i) {
  //     this.mess = i;
  //   },
  //   handleChange(i) {
  //     console.log(i);
  //   },
  //   deleteClick() {
  //     this.list.pop();
  //   },
  // },
  // mounted() {
  //   this.$refs.child.$on("xdd", (i) => {
  //     console.log(i);
  //   });
  // },
};
</script>

<style>
</style>
