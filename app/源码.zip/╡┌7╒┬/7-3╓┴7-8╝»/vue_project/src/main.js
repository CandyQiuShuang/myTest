import Vue from 'vue';
import App from './App.vue';
import { myMixin } from './mixin';

Vue.config.productionTip = false;

Vue.mixin(myMixin);

new Vue({
  el: '#app',
  beforeCreate() {
    Vue.prototype.$bus = this;
  },
  render: (h) => h(App),
});
