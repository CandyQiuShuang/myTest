export const myMixin = {
  data() {
    return {
      xd: '小滴课堂',
    };
  },
  mounted() {
    console.log('hello from xdclass.net');
  },
};
