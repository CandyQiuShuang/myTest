<template>
  <div>
    <h1 @click="change">{{ hobby }}</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: "小滴课堂",
      hobby: this.msg,
    };
  },
  props: ["msg", "transmit"],
  methods: {
    change() {
      this.hobby = "香蕉";
    },
  },
  mounted() {
    console.log(typeof this.msg);
    this.transmit(this.name);
  },
};
</script>

<style>
</style>
