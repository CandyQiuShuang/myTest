<template>
  <div>
    <h1 @click="handleClick">第一个组件</h1>
    <ul>
      <li v-for="(i, index) in list" :key="index">{{ i }}</li>
    </ul>
    <XDclass />
  </div>
</template>

<script>
import XDclass from "./XDclass.vue";
export default {
  data() {
    return {
      text: "第一个组件的数据",
    };
  },
  components: {
    XDclass,
  },
  props: ["list"],
  methods: {
    handleClick() {
      this.$emit("xd", this.text);
    },
  },
};
</script>

<style>
</style>