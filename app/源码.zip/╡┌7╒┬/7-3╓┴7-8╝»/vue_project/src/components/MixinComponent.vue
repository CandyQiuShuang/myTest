<template>
  <div>{{ xd }}</div>
</template>

<script>
// import { myMixin } from "../mixin";
export default {
  data() {
    return {
      xd: "xiaodi",
    };
  },
  // mixins: [myMixin],
};
</script>

<style>
</style>