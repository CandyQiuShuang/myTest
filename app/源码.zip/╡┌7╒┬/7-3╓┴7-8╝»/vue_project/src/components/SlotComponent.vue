<template>
  <div>
    <slot :list="list"></slot>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: ["苹果", "香蕉", "橙子"],
    };
  },
};
</script>

<style>
</style>