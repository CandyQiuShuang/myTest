<template>
  <div>
    <h1 @click="handleClcik">第二个组件</h1>
    <!-- <button @click="deleteClick">解绑</button> -->
    <button @click="deleteClicks">删除</button>
    <button @click="clickChange">触发</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      textb: "第二个组件数据",
    };
  },
  props: ["deleteClick"],
  methods: {
    handleClcik() {
      this.$emit("xdd", this.textb);
    },
    // deleteClick() {
    //   this.$off();
    // },
    deleteClicks() {
      this.deleteClick();
    },
    clickChange() {
      this.$bus.$emit("xiaodi", this.textb);
    },
  },
};
</script>

<style>
</style>