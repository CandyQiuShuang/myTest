<template>
  <div>
    我是xd组件
    {{ text }}
    <button @click="jiebang">解绑</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      text: "",
    };
  },
  methods: {
    jiebang() {
      this.$bus.$off();
    },
  },
  mounted() {
    this.$bus.$on("xiaodi", (i) => {
      this.text = i;
    });
  },
};
</script>

<style>
</style>