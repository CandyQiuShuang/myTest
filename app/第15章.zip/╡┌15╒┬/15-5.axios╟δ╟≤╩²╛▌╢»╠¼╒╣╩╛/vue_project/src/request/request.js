import axios from 'axios';

axios.defaults.baseUrl = 'http://localhost:8080/';

export default axios;
