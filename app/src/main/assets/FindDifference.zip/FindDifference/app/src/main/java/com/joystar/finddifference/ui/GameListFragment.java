package com.joystar.finddifference.ui;

import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.joystar.finddifference.R;
import com.joystar.finddifference.base.BaseFragment;

public class GameListFragment extends BaseFragment {

    private ImageView mIvBack;
    private RadioGroup mRadioGroup;
    private GridView mGridView;
    private TextView mTvDownload;

    @Override
    public int getLayout() {
        return R.layout.fragment_game_list;
    }

    @Override
    protected void initView() {
        mIvBack = findViewById(R.id.iv_list_back);
        mRadioGroup = findViewById(R.id.radio_group);
        mGridView = findViewById(R.id.grid_view);
        mTvDownload = findViewById(R.id.tv_download);
    }

    @Override
    protected void initListener() {
        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.rb_unselved:
                        break;
                    case R.id.rb_selved:
                        break;
                    case R.id.rb_all:
                        break;
                }
            }
        });
        mIvBack.setOnClickListener(this);
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void setViewData() {

    }

    @Override
    protected void addClick(View v) {
        int id = v.getId();
        if (id == R.id.iv_list_back){
            mOnHideFragmentListener.onHideFragment(true);
        }
    }

    @Override
    public boolean interceptBackPressed() {
        mOnHideFragmentListener.onHideFragment(true);
        return true;
    }
}
