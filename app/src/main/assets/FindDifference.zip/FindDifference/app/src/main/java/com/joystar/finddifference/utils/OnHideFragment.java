package com.joystar.finddifference.utils;


/**
 * 隐藏其他Fragment回调接口
 */
public interface OnHideFragment {
    void onHideFragment(boolean hideFragment);
}
