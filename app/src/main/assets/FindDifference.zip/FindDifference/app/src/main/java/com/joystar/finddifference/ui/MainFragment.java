package com.joystar.finddifference.ui;

import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.joystar.finddifference.R;
import com.joystar.finddifference.base.BaseFragment;

public class MainFragment extends BaseFragment {

    private ImageView mIvSet, mIvHelp, mIvShare, mIvMedal, mIvScore;
    private TextView mTvPlay, mTvRestart, mTvChoooseLv;

    @Override
    public int getLayout() {
        return R.layout.fragment_main;
    }

    @Override
    protected void initView() {
        mIvSet = findViewById(R.id.iv_set);
        mIvHelp = findViewById(R.id.iv_help);
        mIvShare = findViewById(R.id.iv_share);
        mIvMedal = findViewById(R.id.iv_medal);
        mIvScore = findViewById(R.id.iv_score);
        mTvPlay = findViewById(R.id.tv_play);
        mTvRestart = findViewById(R.id.tv_restart);
        mTvChoooseLv = findViewById(R.id.tv_chooose_lv);
    }

    @Override
    protected void initListener() {

        mIvSet.setOnClickListener(this);
        mIvHelp.setOnClickListener(this);
        mIvShare.setOnClickListener(this);
        mIvMedal.setOnClickListener(this);
        mIvScore.setOnClickListener(this);

        mTvPlay.setOnClickListener(this);
        mTvRestart.setOnClickListener(this);
        mTvChoooseLv.setOnClickListener(this);
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void setViewData() {

    }

    @Override
    protected void addClick(View v) {
        MainActivity mainActivity = (MainActivity) mActivity;
        int id = v.getId();
        if (id == R.id.iv_set) {

        } else if (id == R.id.iv_help) {
            mainActivity.initHelpFragment();
        } else if (id == R.id.iv_share) {
            allShare();
        } else if (id == R.id.iv_medal) {

        } else if (id == R.id.iv_score) {

        } else if (id == R.id.tv_play) {
            mainActivity.initGameFragment();
        } else if (id == R.id.tv_restart) {

        } else if (id == R.id.tv_chooose_lv) {
            mainActivity.initGameListFragment();
        }
    }

    /**
     * Android原生分享功能
     * 默认选取手机所有可以分享的APP
     */
    public void allShare() {
        Intent share_intent = new Intent();
        share_intent.setAction(Intent.ACTION_SEND);//设置分享行为
        share_intent.setType("text/plain");//设置分享内容的类型
        share_intent.putExtra(Intent.EXTRA_SUBJECT, "share");//添加分享内容标题
        share_intent.putExtra(Intent.EXTRA_TEXT, "share with you:" + "android");//添加分享内容
        //创建分享的Dialog
        share_intent = Intent.createChooser(share_intent, "share");
        startActivity(share_intent);
    }
}
