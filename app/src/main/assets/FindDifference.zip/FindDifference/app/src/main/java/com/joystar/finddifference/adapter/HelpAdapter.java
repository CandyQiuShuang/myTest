package com.joystar.finddifference.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class HelpAdapter extends PagerAdapter {

    private List<View> mItems;

    public HelpAdapter(List<View> mItems) {
        this.mItems = mItems;
    }

    public void setData(List<View> beans) {
        if (null == mItems) {
            mItems = new ArrayList<>();
        }
        mItems.clear();
        if (beans != null && !beans.isEmpty()) {
            mItems.addAll(beans);
        }
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (mItems != null) {
            return mItems.size();
        }
        return 0;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = mItems.get(position);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        View view = mItems.get(position);
        //前一张图片划过后删除该View
        container.removeView(view);
    }
}
