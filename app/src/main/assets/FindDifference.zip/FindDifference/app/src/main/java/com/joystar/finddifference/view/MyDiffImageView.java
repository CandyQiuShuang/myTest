package com.joystar.finddifference.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import androidx.annotation.IntDef;
import androidx.annotation.Nullable;

import com.joystar.finddifference.R;
import com.joystar.finddifference.bean.PositionModule;
import com.joystar.finddifference.utils.LogUtil;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class MyDiffImageView extends View {

    private Context mContext;
    /**
     * 是否可点击
     */
    private boolean mClickable = true;

    /**
     * 点击图片画笔
     */
    private Paint mImagePaint;
    private Bitmap mWrong;
    private Bitmap mRight;
    /**
     * 点击图片半径
     */
    private int mClickImgRadius = 70;
    /**
     * 图片抗锯齿
     */
    private PaintFlagsDrawFilter mPaintFlagsDrawFilter;

    private boolean isDoubleTap = false;

    /**
     * 可点击的区域的中心点
     */
    private List<PositionModule> mDiffAreas = new ArrayList<>();
    /**
     * 上一次点击的坐标
     */
    private Point mTrackerPoint = new Point(-1, -1);

    /**
     * 已经触发的绘制区域
     */
    private HashSet<PositionModule> mSolveAreas = new HashSet<>();

    private int mViewWidth;
    private int mViewHeight;

    private ScaleGestureDetector mScaleDetector;
    private GestureDetector mGestureDetector;
    /**
     * 点击回调监听
     */
    private ClickListener mClickListener;
    private Bitmap mDiffImage;

    // 画布当前的 Matrix， 用于获取当前画布的一些状态信息，例如缩放大小，平移距离等
    private Matrix mCanvasMatrix = new Matrix();

    // 将用户触摸的坐标转换为画布上坐标所需的 Matrix， 以便找到正确的缩放中心位置
    private Matrix mInvertMatrix = new Matrix();

    // 所有用户触发的缩放、平移等操作都通过下面的 Matrix 直接作用于画布上，
    // 将系统计算的一些初始缩放平移信息与用户操作的信息进行隔离，让操作更加直观
    private Matrix mUserMatrix = new Matrix();

    // 基础的缩放和平移信息，该信息与用户的手势操作无关
    private float mBaseScale = 1;
    private float mBaseTranslateX;
    private float mBaseTranslateY;

    public MyDiffImageView(Context context) {
        this(context, null);
    }

    public MyDiffImageView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MyDiffImageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        init();
    }

    private void init() {
        mImagePaint = new Paint();
        mImagePaint.setAntiAlias(true);
        mImagePaint.setStyle(Paint.Style.FILL);

        mWrong = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_wrong);
        mRight = BitmapFactory.decodeResource(getResources(), R.mipmap.icon_right);

        mPaintFlagsDrawFilter = new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        mScaleDetector = new ScaleGestureDetector(mContext, new MyDiffImageView.ScaleListener());
        mGestureDetector = new GestureDetector(mContext, new MyDiffImageView.GestureListener());


    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mViewWidth = w;
        mViewHeight = h;

        mBaseTranslateX = 0;
        mBaseTranslateY = 0;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.translate(mBaseTranslateX, mBaseTranslateY);
        canvas.scale(mBaseScale, mBaseScale);

        canvas.save();
        canvas.concat(mUserMatrix);
        canvas.setDrawFilter(mPaintFlagsDrawFilter);
        mCanvasMatrix = canvas.getMatrix();
        mCanvasMatrix.invert(mInvertMatrix);
        RectF rectF = new RectF(0, 0, mViewWidth, mViewHeight);
        canvas.drawBitmap(mDiffImage, null, rectF, mImagePaint);
        if (mTrackerPoint.x > -1) {
            drawLastPosition(canvas);
        }
        drawClickedArea(canvas);
        canvas.restore();
    }


    private void drawLastPosition(Canvas canvas) {
        RectF rectF = new RectF((mTrackerPoint.x - mClickImgRadius), (mTrackerPoint.y - mClickImgRadius), (mTrackerPoint.x + mClickImgRadius), (mTrackerPoint.y + mClickImgRadius));
        canvas.drawBitmap(mWrong, null, rectF, mImagePaint);
        LogUtil.e("drawLastPosition", "Left = " + (mTrackerPoint.x - mClickImgRadius) + " top = " + (mTrackerPoint.y - mClickImgRadius) + " right = " + (mTrackerPoint.x + mClickImgRadius) + " buttom = " + (mTrackerPoint.y + mClickImgRadius) / mBaseScale);
    }

    private void drawClickedArea(Canvas canvas) {
        if (mSolveAreas.size() > 0) {
            for (PositionModule p : mSolveAreas) {
                RectF rectF = new RectF((p.getX() - mClickImgRadius), (p.getY() - mClickImgRadius), (p.getX() + mClickImgRadius), (p.getY() + mClickImgRadius));
                LogUtil.e("drawClickedArea", "Left = " + (p.getX() - mClickImgRadius) + " top = " + (p.getY() - mClickImgRadius) + " right = " + (p.getX() + mClickImgRadius) + " buttom = " + (p.getY() + mClickImgRadius));
                canvas.drawBitmap(mRight, null, rectF, mImagePaint);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        mScaleDetector.onTouchEvent(event);
        mGestureDetector.onTouchEvent(event);
        /*if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            fixTranslate();
        }*/
        return true;
    }


    /**
     * ScaleListener detects user two finger scaling and scales image.
     * 检测用户的两个手指缩放和缩放图像。
     *
     * @author Ortiz
     */
    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        @Override
        public boolean onScaleBegin(ScaleGestureDetector detector) {
            return true;
        }

        @Override
        public boolean onScale(ScaleGestureDetector detector) {
            float scaleFactor = detector.getScaleFactor();
            float fx = detector.getFocusX();
            float fy = detector.getFocusY();
            float[] points = mapPoint(fx, fy, mInvertMatrix);
            scaleFactor = getRealScaleFactor(scaleFactor);

            mUserMatrix.preScale(scaleFactor, scaleFactor, points[0], points[1]);
            fixTranslate();
            invalidate();
            return true;
        }

        @Override
        public void onScaleEnd(ScaleGestureDetector detector) {
            super.onScaleEnd(detector);
        }
    }

    /**
     * Gesture Listener detects a single click or long click and passes that on
     * to the view's listener.
     * 检测到一次点击或长时间点击，并将其传递给视图的侦听器。
     *
     * @author Ortiz
     */
    private class GestureListener extends GestureDetector.SimpleOnGestureListener {

        @Override
        public boolean onSingleTapConfirmed(MotionEvent e) {
            if (!mClickable) {
                return false;
            }

            if (mClickListener != null) {
                mClickListener.clicked();
            }
            if (!isDoubleTap) {
                showClickArea(e);
            }
            return performClick();
        }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            float scale = getMatrixValue(MSCALE_X, mCanvasMatrix);
            float scrollX = -distanceX / scale;
            float scrollY = -distanceY / scale;
            LogUtil.e("onScroll", "scrollX = " + scrollX + "  scrollY = " + scrollY);
            mUserMatrix.preTranslate(scrollX, scrollY);
            fixTranslate();   // 在用户滚动时不进行修正，保证用户滚动时也有响应， 在用户抬起手指后进行修正
            invalidate();
            return true;
        }


        @Override
        public boolean onDoubleTap(MotionEvent e) {
            if (!mClickable) {
                return false;
            }
            if (mClickListener != null) {
                mClickListener.doubleClicked();
            }
            if (isDoubleTap) {
                showClickArea(e);
            }
            return true;
        }
    }


    // 修正缩放
    private void fixTranslate() {
        // 对 Matrix 进行预计算，并根据计算结果进行修正
        Matrix viewMatrix = getMatrix();    // 获取当前控件的Matrix
        viewMatrix.preTranslate(mBaseTranslateX, mBaseTranslateY);
        viewMatrix.preScale(mBaseScale, mBaseScale);
        viewMatrix.preConcat(mUserMatrix);
        Matrix invert = new Matrix();
        viewMatrix.invert(invert);
        Rect rect = new Rect();
        getGlobalVisibleRect(rect);

        float userScale = getMatrixValue(MSCALE_X, mUserMatrix);
        float scale = getMatrixValue(MSCALE_X, viewMatrix);

        float[] center = mapPoint(mViewWidth / 2.0f, mViewHeight / 2.0f, viewMatrix);
        float distanceX = center[0] - getWidth() / 2.0f;
        float distanceY = center[1] - getHeight() / 2.0f;
        float[] wh = mapVectors(mViewWidth, mViewHeight, viewMatrix);

        if (userScale <= 1.0f) {
            mUserMatrix.preTranslate(-distanceX / scale, -distanceY / scale);
        } else {
            float[] lefttop = mapPoint(0, 0, viewMatrix);
            float[] rightbottom = mapPoint(mViewWidth, mViewHeight, viewMatrix);

            // 如果宽度小于总宽度，则水平居中
            if (wh[0] < getWidth()) {
                mUserMatrix.preTranslate(distanceX / scale, 0);
            } else {
                if (lefttop[0] > 0) {
                    mUserMatrix.preTranslate(-lefttop[0] / scale, 0);
                } else if (rightbottom[0] < getWidth()) {
                    mUserMatrix.preTranslate((getWidth() - rightbottom[0]) / scale, 0);
                }

            }
            // 如果高度小于总高度，则垂直居中
            if (wh[1] < getHeight()) {
                mUserMatrix.preTranslate(0, -distanceY / scale);
            } else {
                if (lefttop[1] > 0) {
                    mUserMatrix.preTranslate(0, -lefttop[1] / scale);
                } else if (rightbottom[1] < getHeight()) {
                    mUserMatrix.preTranslate(0, (getHeight() - rightbottom[1]) / scale);
                }
            }
        }
        invalidate();
    }

    //--- 将坐标转换为画布坐标 ---
    private float[] mapPoint(float x, float y, Matrix matrix) {
        float[] temp = new float[2];
        temp[0] = x;
        temp[1] = y;
        matrix.mapPoints(temp);
        return temp;
    }

    private float[] mapVectors(float x, float y, Matrix matrix) {
        float[] temp = new float[2];
        temp[0] = x;
        temp[1] = y;
        matrix.mapVectors(temp);
        return temp;
    }

    //--- 获取 Matrix 中的属性 ---
    private float[] matrixValues = new float[9];
    private static final int MSCALE_X = 0, MSKEW_X = 1, MTRANS_X = 2;
    private static final int MSKEW_Y = 3, MSCALE_Y = 4, MTRANS_Y = 5;
    private static final int MPERSP_0 = 6, MPERSP_1 = 7, MPERSP_2 = 8;

    @IntDef({MSCALE_X, MSKEW_X, MTRANS_X, MSKEW_Y, MSCALE_Y, MTRANS_Y, MPERSP_0, MPERSP_1, MPERSP_2})
    @Retention(RetentionPolicy.SOURCE)
    private @interface MatrixName {
    }

    private float getMatrixValue(@MatrixName int name, Matrix matrix) {
        matrix.getValues(matrixValues);
        return matrixValues[name];
    }

    //--- 限制缩放比例 ---
    private float MAX_SCALE = 1.5f;     //最大缩放比例
    private float MIN_SCALE = 1f;       //最小缩放比例

    private float getRealScaleFactor(float currentScaleFactor) {
        float realScale = 1.0f;
        float userScale = getMatrixValue(MSCALE_X, mUserMatrix);    // 用户当前的缩放比例
        float theoryScale = userScale * currentScaleFactor;           // 理论缩放数值
        mBaseScale = userScale;
        // 如果用户在执行放大操作并且理论缩放数据大于2.0
        if (currentScaleFactor > 1.0f && theoryScale > MAX_SCALE) {
            realScale = MAX_SCALE / userScale;

        } else if (currentScaleFactor < 1.0f && theoryScale < MIN_SCALE) {
            realScale = MIN_SCALE / userScale;
        } else {
            realScale = currentScaleFactor;
        }

        LogUtil.e("onScale", "mBaseScale == " + mBaseScale);
        return realScale;
    }

    /**
     * 显示点击区域
     *
     * @param event
     */
    private void showClickArea(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        float rawX = event.getRawX();
        float rawY = event.getRawY();
        LogUtil.e("MotionEvent", "localRect.left == " + getLeft() + "localRect.top == " + getTop() + "  X == " + x + "  Y ==" + y + "  mBaseScale == " + mBaseScale);
        if (mDiffAreas.size() == 0) {
            return;
        }
        PositionModule nearPos = isNearby(x, y);
        if (nearPos != null) {
            // 绘制不相同的区域
            mSolveAreas.add(nearPos);
            if (mClickListener != null) {
                mClickListener.onClickRightArea(this, nearPos);
                if (mSolveAreas.size() == mDiffAreas.size()) {
                    mClickListener.complete();
                }
            }
            mTrackerPoint.x = -1;
            mTrackerPoint.y = -1;
        } else {
            // 绘制跟踪点
            mTrackerPoint.x = (int) event.getX();
            mTrackerPoint.y = (int) event.getY();
        }
        invalidate();
    }

    private PositionModule isNearby(float x, float y) {
        for (PositionModule p : mDiffAreas) {
            double a = Math.pow(p.getX() - x / mBaseScale, 2);
            double b = Math.pow(p.getY() - y / mBaseScale, 2);
            double distance = Math.sqrt(a + b);
            if (distance < mClickImgRadius * 1.1) {
                return p;
            }
        }
        return null;
    }


    public void setImageResource(int resId) {
        mDiffImage = BitmapFactory.decodeResource(getResources(), resId);
        invalidate();
    }

    public void setDiffAreas(List<PositionModule> areas) {
        mDiffAreas.clear();
        mDiffAreas.addAll(areas);
        for (int i = 0; i < areas.size(); i++) {
            PositionModule module = areas.get(i);
            LogUtil.e("mDiffAreas", "positionX = " + module.getX() + " ; positionY = " + module.getY());
        }
        invalidate();
    }

    public void showDiffArea(PositionModule point) {
        mSolveAreas.add(point);
        invalidate();
    }

    public void setClickHideAreaListener(ClickListener clickListener) {
        mClickListener = clickListener;
    }

    @Override
    public void setClickable(boolean clickable) {
        super.setClickable(clickable);
        mClickable = clickable;
    }

  /*  public void setZoom(MyDiffImageView img) {
        PointF center = img.getScrollPosition();
        mUserMatrix.preTranslate(center.x, center.y);
        fixTranslate();   // 在用户滚动时不进行修正，保证用户滚动时也有响应， 在用户抬起手指后进行修正
        invalidate();
    }

    public float getCurrentZoom() {
        return mBaseScale;
    }

    public PointF getScrollPosition() {
        Drawable drawable = getBackground();
        if (drawable == null) {
            return null;
        }
        int drawableWidth = drawable.getIntrinsicWidth();
        int drawableHeight = drawable.getIntrinsicHeight();

        PointF point = mapPoint(mViewWidth / 2, mViewHeight / 2, true);
        point.x /= drawableWidth;
        point.y /= drawableHeight;
        return point;
    }*/

    public interface ClickListener {

        void onClickRightArea(View view, PositionModule point);

        void clicked();

        void doubleClicked();

        void complete();

    }
}
