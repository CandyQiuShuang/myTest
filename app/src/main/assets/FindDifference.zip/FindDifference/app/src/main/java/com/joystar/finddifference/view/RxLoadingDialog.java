package com.joystar.finddifference.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;

import com.joystar.finddifference.R;


/**
 * Created by john on 2018/1/8.
 */

public class RxLoadingDialog extends Dialog {

    private ImageView mImage;
    private Context mContext;
    private MaterialProgressDrawable mProgress;
    private final int CIRCLE_BG_LIGHT = 0xFFFFFFFF;
    private int[] colors = {0xFF5B79FB};
    private ValueAnimator valueAnimator;
    boolean visable = false;

    public RxLoadingDialog(Context context) {
        super(context, R.style.MyDialog);
        setCanceledOnTouchOutside(false);
        mContext = context;
        initView();
    }
    private void initView() {

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_loading, null);
        mImage = dialogView.findViewById(R.id.image);
        mProgress = new MaterialProgressDrawable(mContext,mImage);
        mProgress.setBackgroundColor(CIRCLE_BG_LIGHT);
        //圈圈颜色,可以是多种颜色
        mProgress.setColorSchemeColors(colors);
        //设置圈圈的各种大小
        mProgress.updateSizes(MaterialProgressDrawable.DEFAULT);
        mImage.setImageDrawable(mProgress);
        setContentView(dialogView);
    }

    @Override
    public void show() {
        showDialog();
        super.show();
    }

    @Override
    public void cancel() {
        super.cancel();
    }

    public void showDialog () {
        if(valueAnimator == null) {
            valueAnimator = valueAnimator.ofFloat(0f,1f);
            valueAnimator.setDuration(600);
            valueAnimator.setInterpolator(new DecelerateInterpolator());
            valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    float n = (float) animation.getAnimatedValue();
                    //圈圈的旋转角度
                    mProgress.setProgressRotation(n * 0.5f);
                    //圈圈周长，0f-1F
                    mProgress.setStartEndTrim(0f, n * 0.8f);
                    //箭头大小，0f-1F
                    mProgress.setArrowScale(n);
                    //透明度，0-255
                    mProgress.setAlpha((int) (255 * n));
                }
            });
            valueAnimator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    visable = true;
                    mProgress.start();
                }
            });
        }
        if(!valueAnimator.isRunning()) {
            if(!visable) {
                //是否显示箭头
                mProgress.showArrow(true);
                valueAnimator.start();
            }
            else {
            }
        }
    }
}
