package com.joystar.finddifference.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.joystar.finddifference.R;
import com.joystar.finddifference.adapter.HelpAdapter;
import com.joystar.finddifference.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import me.relex.circleindicator.CircleIndicator;

public class HelpFragment extends BaseFragment {

    private List<View> ImageViews = new ArrayList<>();

    private ImageView mIvBack;
    private ViewPager mViewPager;
    private CircleIndicator mIndicator;
    private TextView mTvHelpDesc;
    private int helpImgs[] = {R.mipmap.icon_help1,
            R.mipmap.icon_help2,
            R.mipmap.icon_help3,
            R.mipmap.icon_help4,
            R.mipmap.icon_help5,
            R.mipmap.icon_help6,
            R.mipmap.icon_help7};
    private HelpAdapter mAdapter;

    @Override
    public int getLayout() {
        return R.layout.fragment_help;
    }

    @Override
    protected void initView() {
        mIvBack = findViewById(R.id.iv_back);
        mViewPager = findViewById(R.id.viewpager);
        mIndicator = findViewById(R.id.indicator);
        mTvHelpDesc = findViewById(R.id.tv_help_desc);
    }

    @Override
    protected void initListener() {
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                        mTvHelpDesc.setText(R.string.help_desc);
                        break;
                    case 1:
                        mTvHelpDesc.setText(R.string.help_desc1);
                        break;
                    case 2:
                        mTvHelpDesc.setText(R.string.help_desc2);
                        break;
                    case 3:
                        mTvHelpDesc.setText(R.string.help_desc3);
                        break;
                    case 4:
                        mTvHelpDesc.setText(R.string.help_desc4);
                        break;
                    case 5:
                        mTvHelpDesc.setText(R.string.help_desc5);
                        break;
                    case 6:
                        mTvHelpDesc.setText(R.string.help_desc6);
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        mIvBack.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        for (int i = 0; i < helpImgs.length; i++) {
            ImageView imageView = new ImageView(mActivity);
            imageView.setImageResource(helpImgs[i]);
            ImageViews.add(imageView);
        }
    }

    @Override
    protected void setViewData() {
        mAdapter = new HelpAdapter(ImageViews);
        mViewPager.setAdapter(mAdapter);
        mIndicator.setViewPager(mViewPager);
        mAdapter.registerDataSetObserver(mIndicator.getDataSetObserver());
    }

    @Override
    protected void addClick(View v) {
        if (v.getId() == R.id.iv_back) {
            mOnHideFragmentListener.onHideFragment(true);
        }
    }

    @Override
    public boolean interceptBackPressed() {
        mOnHideFragmentListener.onHideFragment(true);
        return true;
    }
}
