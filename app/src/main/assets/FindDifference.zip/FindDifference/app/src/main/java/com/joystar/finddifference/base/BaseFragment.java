package com.joystar.finddifference.base;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.joystar.finddifference.utils.BackHandlerHelper;
import com.joystar.finddifference.utils.FragmentBackHandler;
import com.joystar.finddifference.utils.LogUtil;
import com.joystar.finddifference.utils.OnHideFragment;


public abstract class BaseFragment extends Fragment implements View.OnClickListener , FragmentBackHandler,View.OnTouchListener {
    protected final String TAG = this.getClass().getSimpleName();
    protected Activity mActivity;
    protected View mRootView;
    protected OnHideFragment mOnHideFragmentListener;


    /**
     * 获得全局的，防止使用getActivity()为空
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mActivity = getActivity();
        if (context instanceof OnHideFragment){
            mOnHideFragmentListener = (OnHideFragment) context;
        }
        LogUtil.e(TAG, TAG + " -->>onAttach");
    }

    //实例化成员变量
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.e(TAG, TAG + " -->>onCreate");
    }

    //给当前的fragment绘制UI布局，可以使用线程更新UI
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.e(TAG, TAG + " -->>onCreateView");
        if (mRootView != null) {
            ViewGroup parent = (ViewGroup) mRootView.getParent();
            if (parent != null) {
                parent.removeView(mRootView);
            }
        }
        mRootView = inflater.inflate(getLayout(), container, false);

        return mRootView;
    }

    //表示activity执行oncreate方法完成了的时候会调用此方法
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LogUtil.e(TAG, TAG + " -->>onActivityCreated");
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // 拦截触摸事件，防止泄露下去
        view.setOnTouchListener(this);
        LogUtil.e(TAG, TAG + " -->>onViewCreated");
        initView();
        initListener();
        initData();
        setViewData();
    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.e(TAG, TAG + " -->>onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.e(TAG, TAG + " -->>onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.e(TAG, TAG + " -->>onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.e(TAG, TAG + " -->>onStop");
    }

    //表示fragment销毁相关联的UI布局
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        LogUtil.e(TAG, TAG + " -->>onDestroyView");
    }

    //销毁fragment对象
    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.e(TAG, TAG + " -->>onDestroy");
    }

    //脱离activity
    @Override
    public void onDetach() {
        super.onDetach();
        LogUtil.e(TAG, TAG + " -->>onDetach");
    }


    public String getTAG() {
        return TAG;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return true;
    }

    /**
     * 设置布局
     *
     * @return
     */
    public abstract int getLayout();

    /**
     * 初始化布局
     */
    protected abstract void initView();

    /**
     * 初始化点击事件监听器
     */
    protected abstract void initListener();

    /**
     * 初始化数据
     */
    protected abstract void initData();


    /**
     * 初始化数据
     */
    protected abstract void setViewData();

    /**
     * 点击
     */
    protected abstract void addClick(View v);

    @SuppressWarnings("unchecked")
    protected <T extends View> T findViewById(int id) {
        if (mRootView == null) {
            return null;
        }

        return (T) mRootView.findViewById(id);
    }

    @Override
    public void onClick(View v) {
        addClick(v);
    }


   /* @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        // 恢复UI状态
        if (savedInstanceState != null && getView() != null) {
            SparseArray<Parcelable> sparseArray = savedInstanceState.getSparseParcelableArray(VIEWS_TAG);
            getView().restoreHierarchyState(sparseArray);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // 保存UI状态
        SparseArray<Parcelable> sparseArray = new SparseArray<Parcelable>();
        if (getView() != null) {
            getView().saveHierarchyState(sparseArray);
            outState.putSparseParcelableArray(VIEWS_TAG, sparseArray);
        }
    }*/

    @Override
    public final boolean onBackPressed() {
        return interceptBackPressed()
                || (getBackHandleViewPager() == null
                ? BackHandlerHelper.handleBackPress(this)
                : BackHandlerHelper.handleBackPress(getBackHandleViewPager()));
    }

    public boolean interceptBackPressed() {
        return false;
    }

    /**
     * 2.1 版本已经不在需要单独对ViewPager处理
     *
     * @deprecated
     */
    @Deprecated
    public ViewPager getBackHandleViewPager() {
        return null;
    }
}
