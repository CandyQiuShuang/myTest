package com.joystar.finddifference.bean;

import java.util.List;

public class DiffInfoBean {

    /**
     * diff_num : 5
     * position : [{"pos_x":95,"pos_y":100},{"pos_x":570,"pos_y":90},{"pos_x":558,"pos_y":214},{"pos_x":278,"pos_y":357},{"pos_x":538,"pos_y":459}]
     */

    private int diff_num;
    private List<PositionBean> position;

    public int getDiff_num() {
        return diff_num;
    }

    public void setDiff_num(int diff_num) {
        this.diff_num = diff_num;
    }

    public List<PositionBean> getPosition() {
        return position;
    }

    public void setPosition(List<PositionBean> position) {
        this.position = position;
    }

    public static class PositionBean {
        /**
         * pos_x : 95
         * pos_y : 100
         */

        private int pos_x;
        private int pos_y;

        public int getPos_x() {
            return pos_x;
        }

        public void setPos_x(int pos_x) {
            this.pos_x = pos_x;
        }

        public int getPos_y() {
            return pos_y;
        }

        public void setPos_y(int pos_y) {
            this.pos_y = pos_y;
        }
    }
}
