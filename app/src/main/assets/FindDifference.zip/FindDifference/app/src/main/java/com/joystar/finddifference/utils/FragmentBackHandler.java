package com.joystar.finddifference.utils;

public interface FragmentBackHandler {
    boolean onBackPressed();
}
