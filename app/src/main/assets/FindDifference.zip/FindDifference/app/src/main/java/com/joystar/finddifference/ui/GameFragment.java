package com.joystar.finddifference.ui;

import android.graphics.Color;
import android.view.View;
import android.widget.ImageView;

import com.joystar.finddifference.R;
import com.joystar.finddifference.base.BaseFragment;
import com.joystar.finddifference.bean.PositionModule;
import com.joystar.finddifference.utils.LogUtil;
import com.joystar.finddifference.view.DiffImageView;
import com.joystar.finddifference.view.DiffNumView;
import com.joystar.finddifference.view.MyDiffImageView;

import java.util.ArrayList;
import java.util.List;

public class GameFragment extends BaseFragment implements MyDiffImageView.ClickListener {

    private MyDiffImageView mDiffDefault;
    private MyDiffImageView mDiffBg;
    private MyDiffImageView mDiffCover;
    private ImageView mIvGameBack;
    private DiffNumView mIvDiffNum;
    private ImageView mIvGameLife;
    private ImageView mIvGameTips;
    private ImageView mIvToBig;
    private ImageView mIvGamePause;
    private int mDiffViewWidth;
    private int mDiffViewHeight;

    @Override
    public int getLayout() {
        return R.layout.fragment_game;
    }

    @Override
    protected void initView() {
        mDiffDefault = findViewById(R.id.diff_default);
        mDiffBg = findViewById(R.id.diff_bg);
        mDiffCover = findViewById(R.id.diff_cover);

        mIvGameBack = findViewById(R.id.iv_game_back);
        mIvDiffNum = findViewById(R.id.iv_diff_num);
        mIvGameLife = findViewById(R.id.iv_game_life);
        mIvGameTips = findViewById(R.id.iv_game_tips);
        mIvToBig = findViewById(R.id.iv_to_big);
        mIvGamePause = findViewById(R.id.iv_game_pause);
    }

    @Override
    protected void initListener() {
      /*  mDiffDefault.setOnTouchImageViewListener(new DiffImageView.OnTouchImageViewListener() {
            @Override
            public void onMove() {
                mDiffBg.setZoom(mDiffDefault);
                mDiffCover.setZoom(mDiffDefault);
                boolean zoomed = mDiffDefault.isZoomed();
                float currentZoom = mDiffDefault.getCurrentZoom();
            }
        });

        mDiffCover.setOnTouchImageViewListener(new DiffImageView.OnTouchImageViewListener() {
            @Override
            public void onMove() {
                mDiffBg.setZoom(mDiffCover);
                mDiffDefault.setZoom(mDiffCover);
            }
        });*/

        mIvGameBack.setOnClickListener(this);
        mIvGameTips.setOnClickListener(this);
        mIvToBig.setOnClickListener(this);
        mIvGamePause.setOnClickListener(this);
    }


    @Override
    protected void initData() {
        mDiffDefault.setImageResource(R.mipmap.pic_normal);
        mDiffBg.setImageResource(R.mipmap.pic_normal);
        mDiffCover.setImageResource(R.mipmap.pic_diff);

        mDiffDefault.post(new Runnable() {
            @Override
            public void run() {
                mDiffViewWidth = mDiffDefault.getWidth();
                mDiffViewHeight = mDiffDefault.getHeight();
                List<PositionModule> areas = new ArrayList<>();
                areas.add(new PositionModule((int) (0.13f * mDiffViewWidth), (int) (0.18f * mDiffViewHeight)));
                areas.add(new PositionModule((int) (0.79f * mDiffViewWidth), (int) (0.16f * mDiffViewHeight)));
                areas.add(new PositionModule((int) (0.78f * mDiffViewWidth), (int) (0.39f * mDiffViewHeight)));
                areas.add(new PositionModule((int) (0.39f * mDiffViewWidth), (int) (0.65f * mDiffViewHeight)));
                areas.add(new PositionModule((int) (0.75f * mDiffViewWidth), (int) (0.83f * mDiffViewHeight)));

                mDiffDefault.setDiffAreas(areas);
                mDiffCover.setDiffAreas(areas);
            }
        });


        mDiffDefault.setClickHideAreaListener(this);
        mDiffCover.setClickHideAreaListener(this);
    }

    @Override
    protected void setViewData() {

    }

    @Override
    protected void addClick(View v) {
        int id = v.getId();
        if (id == R.id.iv_game_back) {
            mOnHideFragmentListener.onHideFragment(true);
        } else if (id == R.id.iv_game_tips) {

        } else if (id == R.id.iv_to_big) {

        } else if (id == R.id.iv_game_pause) {

        }
    }

    @Override
    public boolean interceptBackPressed() {
        mOnHideFragmentListener.onHideFragment(true);
        return true;
    }

    @Override
    public void onClickRightArea(View view, PositionModule point) {
        mDiffDefault.showDiffArea(point);
        mDiffCover.showDiffArea(point);
    }

    @Override
    public void clicked() {

    }

    @Override
    public void doubleClicked() {

    }

    @Override
    public void complete() {
        mDiffDefault.setClickable(false);
        mDiffCover.setClickable(false);
    }
}
