package com.joystar.finddifference.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.joystar.finddifference.R;
import com.joystar.finddifference.utils.BackHandlerHelper;
import com.joystar.finddifference.utils.LogUtil;
import com.joystar.finddifference.utils.OnHideFragment;
import com.joystar.finddifference.utils.StatusBarUtil;
import com.joystar.finddifference.utils.ToastUtil;
import com.joystar.finddifference.view.DiffImageView;
import com.joystar.finddifference.view.StarsView;

public class MainActivity extends AppCompatActivity implements OnHideFragment {
    protected final String TAG = "MainActivity";
    private FrameLayout mFragmentContainer;
    private FragmentManager mFM;
    private FragmentTransaction mFT;
    private MainFragment mMainFragment;
    private HelpFragment mHelpFragment;
    private GameListFragment mListFragment;
    private GameFragment mGameFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initListener();
        initData();
        setViewData();
    }


    private void initView() {
        setBarColor(true);
        mFragmentContainer = findViewById(R.id.fragment_container);
    }


    private void initListener() {

    }


    private void initData() {
        mFM = getSupportFragmentManager();
        initMainFragment();
    }

    private void setViewData() {

    }

    private void initMainFragment() {
        setBarColor(true);
        //开启事务，fragment的控制是由事务来实现的
        mFT = mFM.beginTransaction();
        //第一种方式（add），初始化fragment并添加到事务中，如果为null就new一个
        if (mMainFragment == null) {
            mMainFragment = new MainFragment();
            mFT.add(R.id.fragment_container, mMainFragment, mMainFragment.getTAG());
        }
        //隐藏所有fragment
        hideFragment(mFT);
        //显示需要显示的fragment
        mFT.show(mMainFragment);
        //提交事务
        mFT.commit();
    }

    public void initHelpFragment() {
        setBarColor(true);
        //开启事务，fragment的控制是由事务来实现的
        mFT = mFM.beginTransaction();
        //第一种方式（add），初始化fragment并添加到事务中，如果为null就new一个
        if (mHelpFragment == null) {
            mHelpFragment = new HelpFragment();
            mFT.add(R.id.fragment_container, mHelpFragment, mHelpFragment.getTAG());
        }
        //隐藏所有fragment
        hideFragment(mFT);
        //显示需要显示的fragment
        mFT.show(mHelpFragment);
        //提交事务
        mFT.commit();
    }

    public void initGameListFragment() {
        setBarColor(true);
        //开启事务，fragment的控制是由事务来实现的
        mFT = mFM.beginTransaction();
        //第一种方式（add），初始化fragment并添加到事务中，如果为null就new一个
        if (mListFragment == null) {
            mListFragment = new GameListFragment();
            mFT.add(R.id.fragment_container, mListFragment, mListFragment.getTAG());
        }
        //隐藏所有fragment
        hideFragment(mFT);
        //显示需要显示的fragment
        mFT.show(mListFragment);
        //提交事务
        mFT.commit();
    }

    public void initGameFragment() {
        setBarColor(false);
        //开启事务，fragment的控制是由事务来实现的
        mFT = mFM.beginTransaction();
        //第一种方式（add），初始化fragment并添加到事务中，如果为null就new一个
        if (mGameFragment == null) {
            mGameFragment = new GameFragment();
            mFT.add(R.id.fragment_container, mGameFragment, mGameFragment.getTAG());
        }
        //隐藏所有fragment
        hideFragment(mFT);
        //显示需要显示的fragment
        mFT.show(mGameFragment);
        //提交事务
        mFT.commit();
    }

    /**
     * 隐藏所有Fragment
     *
     * @param ft
     */
    private void hideFragment(FragmentTransaction ft) {
        if (mHelpFragment != null) {
            ft.hide(mHelpFragment);
        }
        if (mGameFragment != null) {
            ft.hide(mGameFragment);
        }
        if (mListFragment != null) {
            ft.hide(mListFragment);
        }
    }

    @Override
    public void onHideFragment(boolean hideFragment) {
        if (hideFragment) {
            initMainFragment();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.e(TAG, TAG + " -->>onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        //AutoSizeConfig.getInstance().setExcludeFontScale(true);
        LogUtil.e(TAG, TAG + " -->>onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.e(TAG, TAG + " -->>onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.e(TAG, TAG + " -->>onStop");
    }


    //销毁对象
    @Override
    public void onDestroy() {
        super.onDestroy();
        LogUtil.e(TAG, TAG + " -->>onDestroy");
    }

    private void setBarColor(boolean isLight) {
        if (isLight) {
            StatusBarUtil.setColor(this, getResources().getColor(R.color.white));
            StatusBarUtil.setDarkMode(this);
        } else {
            StatusBarUtil.setColor(this, getResources().getColor(R.color.black));
            StatusBarUtil.setLightMode(this);
        }
    }


    //记录用户首次点击返回键的时间
    private long firstTime = 0;

    @Override
    public void onBackPressed() {
        if (!BackHandlerHelper.handleBackPress(this)) {
            long secondTime = System.currentTimeMillis();
            if (secondTime - firstTime > 2000) {
                ToastUtil.showToast(R.string.exit_app);
                firstTime = secondTime;
            } else {
                finish();
                System.exit(0);
            }
        }
        LogUtil.e("mFM.getBackStackEntryCount()" + mFM.getBackStackEntryCount());
    }
}