package com.joystar.finddifference.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;

import androidx.annotation.Nullable;

import com.joystar.finddifference.R;
import com.joystar.finddifference.utils.DisplayUtils;

public class DiffNumView extends View {
    private Context mContext;
    // 控件宽
    private int mWidth;
    // 控件高
    private int mHeight;
    //圆形画笔
    private Paint mCirclePaint;
    //圆弧画笔
    private Paint mArcPaint;
    //中心点X Y
    private float mMidx;
    private float mMidy;
    //扇形数 (不同数)
    private int diffNun = 5;
    //找到的不同数
    private int findDiffNum = 0;
    //开始角度
    private int mStartAngle = -90;

    private RectF mRectF;

    private int mMargin;

    public DiffNumView(Context context) {
        this(context, null);
    }

    public DiffNumView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DiffNumView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        init();
    }

    private void init() {
        mMargin = DisplayUtils.dp2px(mContext, 2f);
        mCirclePaint = new Paint();
        mCirclePaint.setAntiAlias(true);
        mCirclePaint.setStyle(Paint.Style.STROKE);
        mCirclePaint.setStrokeWidth(mMargin);
        mCirclePaint.setColor(getResources().getColor(R.color.theme_color));

        mArcPaint = new Paint();
        mArcPaint.setAntiAlias(true);
        mArcPaint.setColor(getResources().getColor(R.color.theme_color));


    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        // 控件宽、高
        mWidth = mHeight = Math.min(h, w) - mMargin;
        mRectF = new RectF(mMargin - 1, mMargin - 1, mWidth + 1, mHeight + 1);
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        mMidx = canvas.getWidth() / 2;
        mMidy = canvas.getHeight() / 2;

        canvas.drawCircle(mMidx, mMidy, mWidth / 2, mCirclePaint);
        float pieStart = mStartAngle;
        float pieSweep = 360 / diffNun;
        for (int i = 0; i < diffNun; i++) {
            //设置弧形颜色
            //绘制弧形区域，以构成饼状图
            if (i < findDiffNum) {
                mArcPaint.setStyle(Paint.Style.FILL);
                mArcPaint.setStrokeWidth(0);
            } else {
                mArcPaint.setStyle(Paint.Style.STROKE);
            }
            canvas.drawArc(mRectF, pieStart, pieSweep, true, mArcPaint);
            //获取下一个弧形的起点
            pieStart += pieSweep;
        }
    }

    public void setDiffNun(int diffNun) {
        this.diffNun = diffNun;
        invalidate();
    }

    public void setFindDiffNum(int findDiffNum) {
        this.findDiffNum = findDiffNum;
        invalidate();
    }

    public int dp2px(float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                getResources().getDisplayMetrics());
    }
}
