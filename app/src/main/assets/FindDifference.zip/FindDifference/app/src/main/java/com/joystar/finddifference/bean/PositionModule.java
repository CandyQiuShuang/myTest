package com.joystar.finddifference.bean;

import androidx.annotation.ColorRes;

public class PositionModule {

    /**
     * 图形中心x坐标
     */
    private int X;
    /**
     * 图形中心y坐标
     */
    private int Y;


    public PositionModule(int x, int y) {
        X = x;
        Y = y;

    }

    public int getX() {
        return X;
    }

    public void setX(int x) {
        X = x;
    }

    public int getY() {
        return Y;
    }

    public void setY(int y) {
        Y = y;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PositionModule point = (PositionModule) o;

        if (point.getX() != point.getX()) return false;
        if (point.getY() != point.getY()) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = getX();
        result = 31 * result + getY();
        return result;
    }

    @Override
    public String toString() {
        return "PositionModule{" +
                "X=" + X +
                ", Y=" + Y +
                '}';
    }
}
