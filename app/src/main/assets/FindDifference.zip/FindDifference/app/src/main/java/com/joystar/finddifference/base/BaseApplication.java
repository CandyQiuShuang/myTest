package com.joystar.finddifference.base;

import android.app.Application;

import com.joystar.finddifference.utils.SharedPreUtil;


public class BaseApplication extends Application {

    private final static String TAG = BaseApplication.class.getSimpleName();
    private static BaseApplication mMyApplication;

    public static BaseApplication getInstance() {
        return mMyApplication;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        mMyApplication = this;

        //初始化SharedPreUtil
        SharedPreUtil.getInstance(this, "find_diff");

      /*  OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(600, TimeUnit.SECONDS)
                .writeTimeout(600, TimeUnit.SECONDS)
                // .addInterceptor(new TokenInterceptor())                 //添加获取token的拦截器
                //其他配置
                .build();
        OkHttpUtils.initClient(okHttpClient);*/

    }
}
