package com.joystar.finddifference.utils;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;

import com.joystar.finddifference.base.BaseApplication;


public class ToastUtil {

    private static Handler handler = new Handler(Looper.getMainLooper());

    private volatile static Toast toast = null;

    /**
     * 根据设置的文本显示
     *
     * @param msg
     */
    public static void showToast(String msg) {
        showToast(msg, Toast.LENGTH_LONG);
    }

    /**
     * 根据设置的资源文件显示
     *
     * @param resId
     */
    public static void showToast(final int resId) {
        showToast(resId, Toast.LENGTH_LONG);
    }

    /**
     * 显示一个文本并且设置时长
     *
     * @param msg
     * @param len
     */
    public static void showToast(final CharSequence msg, final int len) {
        if (TextUtils.isEmpty(msg)) return;
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (toast != null) {
                    toast.setText(msg);
                    toast.setDuration(len);
                } else {
                    toast = Toast.makeText(BaseApplication.getInstance(), msg, len);
                }
                toast.show();
            }
        });
    }

    /**
     * 资源文件方式显示文本
     *
     * @param resId
     * @param len
     */
    public static void showToast(final int resId, final int len) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                synchronized (ToastUtil.class) {
                    if (toast != null) {
                        toast.setText(resId);
                        toast.setDuration(len);
                    } else {
                        toast = Toast.makeText(BaseApplication.getInstance(), resId, len);
                    }
                    toast.show();
                }
            }
        });
    }
}